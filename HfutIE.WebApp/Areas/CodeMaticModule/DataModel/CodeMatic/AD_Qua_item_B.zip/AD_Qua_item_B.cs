//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Qua_item_B
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.16 10:33</date>
    /// </author>
    /// </summary>
    [Description("AD_Qua_item_B")]
    [PrimaryKey("Qua_item_key")]
    public class AD_Qua_item_B : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// Qua_item_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_key")]
        public string Qua_item_key { get; set; }
        /// <summary>
        /// q_item_cate_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("q_item_cate_key")]
        public string q_item_cate_key { get; set; }
        /// <summary>
        /// Qua_item_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_type")]
        public string Qua_item_type { get; set; }
        /// <summary>
        /// Qua_item_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_code")]
        public string Qua_item_code { get; set; }
        /// <summary>
        /// Qua_item_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_name")]
        public string Qua_item_name { get; set; }
        /// <summary>
        /// Qua_item_rec_cate
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_rec_cate")]
        public string Qua_item_rec_cate { get; set; }
        /// <summary>
        /// Qua_item_stan
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_stan")]
        public string Qua_item_stan { get; set; }
        /// <summary>
        /// Qua_Item_upl
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_Item_upl")]
        public Single? Qua_Item_upl { get; set; }
        /// <summary>
        /// Qua_Item_downl
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_Item_downl")]
        public Single? Qua_Item_downl { get; set; }
        /// <summary>
        /// Qua_item_targ
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_targ")]
        public string Qua_item_targ { get; set; }
        /// <summary>
        /// frequency
        /// </summary>
        /// <returns></returns>
        [DisplayName("frequency")]
        public string frequency { get; set; }
        /// <summary>
        /// qua_item_unit
        /// </summary>
        /// <returns></returns>
        [DisplayName("qua_item_unit")]
        public string qua_item_unit { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        /// <summary>
        /// targ_upl
        /// </summary>
        /// <returns></returns>
        [DisplayName("targ_upl")]
        public string targ_upl { get; set; }
        /// <summary>
        /// targ_downl
        /// </summary>
        /// <returns></returns>
        [DisplayName("targ_downl")]
        public string targ_downl { get; set; }
        /// <summary>
        /// Qua_item_rec_point
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_rec_point")]
        public string Qua_item_rec_point { get; set; }
        /// <summary>
        /// picture
        /// </summary>
        /// <returns></returns>
        [DisplayName("picture")]
        public string picture { get; set; }
        /// <summary>
        /// imagepath
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagepath")]
        public string imagepath { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.Qua_item_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.Qua_item_key = KeyValue;
                                            }
        #endregion
    }
}