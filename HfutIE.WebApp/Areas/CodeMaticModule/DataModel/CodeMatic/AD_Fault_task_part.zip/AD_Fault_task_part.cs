//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Fault_task_part
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.11 15:37</date>
    /// </author>
    /// </summary>
    [Description("AD_Fault_task_part")]
    [PrimaryKey("r_part_key")]
    public class AD_Fault_task_part : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// r_part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("r_part_key")]
        public string r_part_key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// product_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name")]
        public string product_name { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// product_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type")]
        public string product_type { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// product_struct_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// product_abb
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_born_code")]
        public string product_born_code { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// eqm_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_key")]
        public string eqm_key { get; set; }
        /// <summary>
        /// eqm_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_code")]
        public string eqm_code { get; set; }
        /// <summary>
        /// eqm_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_name")]
        public string eqm_name { get; set; }
        /// <summary>
        /// part_barcode
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_barcode")]
        public string part_barcode { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// r_part_barcode
        /// </summary>
        /// <returns></returns>
        [DisplayName("r_part_barcode")]
        public string r_part_barcode { get; set; }
        /// <summary>
        /// r_part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("r_part_name")]
        public string r_part_name { get; set; }
        /// <summary>
        /// count
        /// </summary>
        /// <returns></returns>
        [DisplayName("count")]
        public string count { get; set; }
        /// <summary>
        /// part_batch_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_batch_code")]
        public string part_batch_code { get; set; }
        /// <summary>
        /// part_supply_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_supply_code")]
        public string part_supply_code { get; set; }
        /// <summary>
        /// part_supply_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_supply_name")]
        public string part_supply_name { get; set; }
        /// <summary>
        /// input_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("input_time")]
        public string input_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.r_part_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.r_part_key = KeyValue;
                                            }
        #endregion
    }
}