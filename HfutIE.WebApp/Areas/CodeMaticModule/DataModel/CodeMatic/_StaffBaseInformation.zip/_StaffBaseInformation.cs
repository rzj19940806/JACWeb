//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2021
// Software Developers @ HfutIE 2021
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// ��Ա������Ϣ��
    /// <author>
    ///		<name>she</name>
    ///		<date>2021.01.26 18:29</date>
    /// </author>
    /// </summary>
    [Description("��Ա������Ϣ��")]
    [PrimaryKey("StaffID")]
    public class _StaffBaseInformation : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string StaffID { get; set; }
        /// <summary>
        /// ��Ա���
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ա���")]
        public string StaffCode { get; set; }
        /// <summary>
        /// ��Ա����
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ա����")]
        public string StaffName { get; set; }
        /// <summary>
        /// ��Ա�Ա�
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ա�Ա�")]
        public string StaffSex { get; set; }
        /// <summary>
        /// ��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������")]
        public DateTime? Birth { get; set; }
        /// <summary>
        /// ����֤��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����֤��")]
        public string IDCard { get; set; }
        /// <summary>
        /// �ֻ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ֻ�����")]
        public string Phone { get; set; }
        /// <summary>
        /// ��ҵ΢�ź�
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ҵ΢�ź�")]
        public string Wechat { get; set; }
        /// <summary>
        /// ��ԱͼƬ
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ԱͼƬ")]
        public string StaffImage { get; set; }
        /// <summary>
        /// ͼƬ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("ͼƬ����")]
        public string ImageType { get; set; }
        /// <summary>
        /// �˺�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�˺�")]
        public string Account { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string Password { get; set; }
        /// <summary>
        /// ��Ա��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ա��������")]
        public string SkillType { get; set; }
        /// <summary>
        /// ��Ա���ܵȼ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ա���ܵȼ�")]
        public string SkillGrade { get; set; }
        /// <summary>
        /// ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("���")]
        public string MarryStatue { get; set; }
        /// <summary>
        /// ��Ч��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч��")]
        public bool? IsAvailable { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateTime { get; set; }
        /// <summary>
        /// �����ˣ�ForeignKey��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����ˣ�ForeignKey��")]
        public string CreatorID { get; set; }
        /// <summary>
        /// �ϴ��޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ϴ��޸�ʱ��")]
        public DateTime? LastModifiedTime { get; set; }
        /// <summary>
        /// �޸��ˣ�ForeignKey��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��ˣ�ForeignKey��")]
        public string ModifierID { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remarks { get; set; }
        /// <summary>
        /// Ԥ���ֶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ���ֶ�")]
        public string Reserve1 { get; set; }
        /// <summary>
        /// Ԥ���ֶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ���ֶ�")]
        public string Reserve2 { get; set; }
        /// <summary>
        /// Ԥ���ֶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ���ֶ�")]
        public string Reserve3 { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.StaffID = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.StaffID = KeyValue;
                                            }
        #endregion
    }
}