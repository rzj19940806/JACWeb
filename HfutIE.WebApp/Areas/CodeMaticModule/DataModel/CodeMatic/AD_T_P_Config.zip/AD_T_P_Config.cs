//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_T_P_Config
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.01.25 13:54</date>
    /// </author>
    /// </summary>
    [Description("AD_T_P_Config")]
    [PrimaryKey("config_key")]
    public class AD_T_P_Config : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// config_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("config_key")]
        public string config_key { get; set; }
        /// <summary>
        /// t_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("t_key")]
        public string t_key { get; set; }
        /// <summary>
        /// p_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_key")]
        public string p_key { get; set; }
        /// <summary>
        /// num
        /// </summary>
        /// <returns></returns>
        [DisplayName("num")]
        public Single? num { get; set; }
        /// <summary>
        /// status
        /// </summary>
        /// <returns></returns>
        [DisplayName("status")]
        public string status { get; set; }
        /// <summary>
        /// start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time")]
        public DateTime? start_time { get; set; }
        /// <summary>
        /// scrap_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("scrap_time")]
        public DateTime? scrap_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.config_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.config_key = KeyValue;
                                            }
        #endregion
    }
}