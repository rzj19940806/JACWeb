//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2019
// Software Developers @ HfutIE 2019
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AT_DOC_SA2_KEY_PART_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2019.01.08 12:23</date>
    /// </author>
    /// </summary>
    public class AT_DOC_SA2_KEY_PART_INFORBll : RepositoryFactory<AT_DOC_SA2_KEY_PART_INFOR>
    {
    }
}