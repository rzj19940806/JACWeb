//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_EQUIP_MAINTENANCE_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.01 15:00</date>
    /// </author>
    /// </summary>
    [Description("AD_EQUIP_MAINTENANCE_INFOR")]
    [PrimaryKey("EM_Infor_key")]
    public class AD_EQUIP_MAINTENANCE_INFOR : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// EM_Infor_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_Infor_key")]
        public string EM_Infor_key { get; set; }
        /// <summary>
        /// equipment_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_key")]
        public string equipment_key { get; set; }
        /// <summary>
        /// equipment_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_code")]
        public string equipment_code { get; set; }
        /// <summary>
        /// equipment_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_name")]
        public string equipment_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// productline_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_key")]
        public string productline_key { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// Maintenance_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("Maintenance_level")]
        public string Maintenance_level { get; set; }
        /// <summary>
        /// Maintenance_cycle
        /// </summary>
        /// <returns></returns>
        [DisplayName("Maintenance_cycle")]
        public string Maintenance_cycle { get; set; }
        /// <summary>
        /// lead_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("lead_time")]
        public string lead_time { get; set; }
        /// <summary>
        /// CM_description
        /// </summary>
        /// <returns></returns>
        [DisplayName("CM_description")]
        public string CM_description { get; set; }
        /// <summary>
        /// EM_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_code")]
        public string EM_user_code { get; set; }
        /// <summary>
        /// EM_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_name")]
        public string EM_user_name { get; set; }
        /// <summary>
        /// Check_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_code")]
        public string Check_user_code { get; set; }
        /// <summary>
        /// Check_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_name")]
        public string Check_user_name { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.EM_Infor_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.EM_Infor_key = KeyValue;
                                            }
        #endregion
    }
}