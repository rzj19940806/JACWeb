//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AT_P_TcuInformation
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.11.24 09:20</date>
    /// </author>
    /// </summary>
    [Description("AT_P_TcuInformation")]
    [PrimaryKey("ID")]
    public class AT_P_TcuInformation : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("ID")]
        public string ID { get; set; }
        /// <summary>
        /// Order_ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("Order_ID")]
        public string Order_ID { get; set; }
        /// <summary>
        /// ProductBarCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductBarCode")]
        public string ProductBarCode { get; set; }
        /// <summary>
        /// TestFile
        /// </summary>
        /// <returns></returns>
        [DisplayName("TestFile")]
        public string TestFile { get; set; }
        /// <summary>
        /// S19File
        /// </summary>
        /// <returns></returns>
        [DisplayName("S19File")]
        public string S19File { get; set; }
        /// <summary>
        /// TestFileName
        /// </summary>
        /// <returns></returns>
        [DisplayName("TestFileName")]
        public string TestFileName { get; set; }
        /// <summary>
        /// TcuBarCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("TcuBarCode")]
        public string TcuBarCode { get; set; }
        /// <summary>
        /// StartDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("StartDate")]
        public string StartDate { get; set; }
        /// <summary>
        /// StartTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("StartTime")]
        public DateTime? StartTime { get; set; }
        /// <summary>
        /// EndDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("EndDate")]
        public string EndDate { get; set; }
        /// <summary>
        /// EndTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("EndTime")]
        public DateTime? EndTime { get; set; }
        /// <summary>
        /// OKNG
        /// </summary>
        /// <returns></returns>
        [DisplayName("OKNG")]
        public string OKNG { get; set; }
        /// <summary>
        /// ProgramCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProgramCode")]
        public int? ProgramCode { get; set; }
        /// <summary>
        /// Station
        /// </summary>
        /// <returns></returns>
        [DisplayName("Station")]
        public string Station { get; set; }
        /// <summary>
        /// PartCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("PartCode")]
        public string PartCode { get; set; }
        /// <summary>
        /// status
        /// </summary>
        /// <returns></returns>
        [DisplayName("status")]
        public int? status { get; set; }
        /// <summary>
        /// SoftwareNumber
        /// </summary>
        /// <returns></returns>
        [DisplayName("SoftwareNumber")]
        public string SoftwareNumber { get; set; }
        /// <summary>
        /// SoftwareVersion
        /// </summary>
        /// <returns></returns>
        [DisplayName("SoftwareVersion")]
        public string SoftwareVersion { get; set; }
        /// <summary>
        /// Supplier
        /// </summary>
        /// <returns></returns>
        [DisplayName("Supplier")]
        public string Supplier { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.ID = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.ID = KeyValue;
                                            }
        #endregion
    }
}