//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_M_LOT
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.24 17:02</date>
    /// </author>
    /// </summary>
    public class AD_M_LOTBll : RepositoryFactory<AD_M_LOT>
    {
    }
}