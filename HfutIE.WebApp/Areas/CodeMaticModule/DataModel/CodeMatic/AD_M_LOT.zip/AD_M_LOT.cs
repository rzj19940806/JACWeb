//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_M_LOT
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.24 17:02</date>
    /// </author>
    /// </summary>
    [Description("AD_M_LOT")]
    [PrimaryKey("lot_key")]
    public class AD_M_LOT : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// lot_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_key")]
        public string lot_key { get; set; }
        /// <summary>
        /// lot_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_name")]
        public string lot_name { get; set; }
        /// <summary>
        /// lot_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_type")]
        public string lot_type { get; set; }
        /// <summary>
        /// lot_descriptin
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_descriptin")]
        public string lot_descriptin { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// downloadstate
        /// </summary>
        /// <returns></returns>
        [DisplayName("downloadstate")]
        public string downloadstate { get; set; }
        /// <summary>
        /// bom_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("bom_key")]
        public string bom_key { get; set; }
        /// <summary>
        /// site_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_code")]
        public string site_code { get; set; }
        /// <summary>
        /// site_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_name")]
        public string site_name { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// production_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("production_line_code")]
        public string production_line_code { get; set; }
        /// <summary>
        /// production_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("production_line_name")]
        public string production_line_name { get; set; }
        /// <summary>
        /// route_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_key")]
        public string route_key { get; set; }
        /// <summary>
        /// encoding_rules_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("encoding_rules_key")]
        public string encoding_rules_key { get; set; }
        /// <summary>
        /// account_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("account_key")]
        public string account_key { get; set; }
        /// <summary>
        /// is_online
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_online")]
        public int? is_online { get; set; }
        /// <summary>
        /// quantity_yield_initial
        /// </summary>
        /// <returns></returns>
        [DisplayName("quantity_yield_initial")]
        public string quantity_yield_initial { get; set; }
        /// <summary>
        /// is_complete
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_complete")]
        public string is_complete { get; set; }
        /// <summary>
        /// complete_quantity
        /// </summary>
        /// <returns></returns>
        [DisplayName("complete_quantity")]
        public string complete_quantity { get; set; }
        /// <summary>
        /// online_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("online_num")]
        public string online_num { get; set; }
        /// <summary>
        /// offline_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("offline_num")]
        public string offline_num { get; set; }
        /// <summary>
        /// scrap_quantity
        /// </summary>
        /// <returns></returns>
        [DisplayName("scrap_quantity")]
        public string scrap_quantity { get; set; }
        /// <summary>
        /// repair_quantity
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_quantity")]
        public string repair_quantity { get; set; }
        /// <summary>
        /// repair_frequency
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_frequency")]
        public string repair_frequency { get; set; }
        /// <summary>
        /// start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time")]
        public DateTime? start_time { get; set; }
        /// <summary>
        /// p_start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_start_time")]
        public DateTime? p_start_time { get; set; }
        /// <summary>
        /// e_finished_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("e_finished_time")]
        public DateTime? e_finished_time { get; set; }
        /// <summary>
        /// finish_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("finish_time")]
        public DateTime? finish_time { get; set; }
        /// <summary>
        /// product_cycle
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_cycle")]
        public string product_cycle { get; set; }
        /// <summary>
        /// lot_due_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_due_time")]
        public DateTime? lot_due_time { get; set; }
        /// <summary>
        /// year
        /// </summary>
        /// <returns></returns>
        [DisplayName("year")]
        public string year { get; set; }
        /// <summary>
        /// initial_serial_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("initial_serial_number")]
        public string initial_serial_number { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.lot_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.lot_key = KeyValue;
                                            }
        #endregion
    }
}