//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_QUALITY_DATA
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.07.17 08:49</date>
    /// </author>
    /// </summary>
    [Description("AD_P_QUALITY_DATA")]
    [PrimaryKey("data_id")]
    public class AD_P_QUALITY_DATA : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// data_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("data_id")]
        public string data_id { get; set; }
        /// <summary>
        /// pro_data_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_data_id")]
        public string pro_data_id { get; set; }
        /// <summary>
        /// dcs_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("dcs_key")]
        public string dcs_key { get; set; }
        /// <summary>
        /// dcs_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("dcs_name")]
        public string dcs_name { get; set; }
        /// <summary>
        /// parm_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("parm_name")]
        public string parm_name { get; set; }
        /// <summary>
        /// parm_description
        /// </summary>
        /// <returns></returns>
        [DisplayName("parm_description")]
        public string parm_description { get; set; }
        /// <summary>
        /// version_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("version_code")]
        public string version_code { get; set; }
        /// <summary>
        /// upper_control
        /// </summary>
        /// <returns></returns>
        [DisplayName("upper_control")]
        public Single? upper_control { get; set; }
        /// <summary>
        /// lower_control
        /// </summary>
        /// <returns></returns>
        [DisplayName("lower_control")]
        public Single? lower_control { get; set; }
        /// <summary>
        /// target
        /// </summary>
        /// <returns></returns>
        [DisplayName("target")]
        public Single? target { get; set; }
        /// <summary>
        /// upper_theory_control
        /// </summary>
        /// <returns></returns>
        [DisplayName("upper_theory_control")]
        public Single? upper_theory_control { get; set; }
        /// <summary>
        /// lower_theory_control
        /// </summary>
        /// <returns></returns>
        [DisplayName("lower_theory_control")]
        public Single? lower_theory_control { get; set; }
        /// <summary>
        /// theory_target
        /// </summary>
        /// <returns></returns>
        [DisplayName("theory_target")]
        public Single? theory_target { get; set; }
        /// <summary>
        /// data_unit
        /// </summary>
        /// <returns></returns>
        [DisplayName("data_unit")]
        public string data_unit { get; set; }
        /// <summary>
        /// data_addr_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("data_addr_key")]
        public string data_addr_key { get; set; }
        /// <summary>
        /// data_addr_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("data_addr_name")]
        public string data_addr_name { get; set; }
        /// <summary>
        /// data_addr_path
        /// </summary>
        /// <returns></returns>
        [DisplayName("data_addr_path")]
        public string data_addr_path { get; set; }
        /// <summary>
        /// value
        /// </summary>
        /// <returns></returns>
        [DisplayName("value")]
        public Single? value { get; set; }
        /// <summary>
        /// is_ok
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_ok")]
        public int? is_ok { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.data_id = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.data_id = KeyValue;
                                            }
        #endregion
    }
}