//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Wc_User_Config
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.10 09:40</date>
    /// </author>
    /// </summary>
    [Description("AD_Wc_User_Config")]
    [PrimaryKey("wc_user_config_key")]
    public class AD_Wc_User_Config : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// wc_user_config_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_user_config_key")]
        public string wc_user_config_key { get; set; }
        /// <summary>
        /// RoleId
        /// </summary>
        /// <returns></returns>
        [DisplayName("RoleId")]
        public string RoleId { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_key")]
        public string user_key { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.wc_user_config_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.wc_user_config_key = KeyValue;
                                            }
        #endregion
    }
}