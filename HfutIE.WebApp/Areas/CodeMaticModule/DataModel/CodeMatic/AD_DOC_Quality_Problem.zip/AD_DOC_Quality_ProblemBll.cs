//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_DOC_Quality_Problem
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.11 09:53</date>
    /// </author>
    /// </summary>
    public class AD_DOC_Quality_ProblemBll : RepositoryFactory<AD_DOC_Quality_Problem>
    {
    }
}