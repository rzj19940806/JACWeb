//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_DOC_Quality_Problem
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.11 09:53</date>
    /// </author>
    /// </summary>
    [Description("AD_DOC_Quality_Problem")]
    [PrimaryKey("key")]
    public class AD_DOC_Quality_Problem : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// key
        /// </summary>
        /// <returns></returns>
        [DisplayName("key")]
        public string key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// QP_applicant_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_applicant_key")]
        public string QP_applicant_key { get; set; }
        /// <summary>
        /// QP_applicant_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_applicant_code")]
        public string QP_applicant_code { get; set; }
        /// <summary>
        /// QP_applicant_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_applicant_name")]
        public string QP_applicant_name { get; set; }
        /// <summary>
        /// QP_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_user_key")]
        public string QP_user_key { get; set; }
        /// <summary>
        /// QP_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_user_code")]
        public string QP_user_code { get; set; }
        /// <summary>
        /// QP_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_user_name")]
        public string QP_user_name { get; set; }
        /// <summary>
        /// product_serial_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_serial_no")]
        public string product_serial_no { get; set; }
        /// <summary>
        /// lot_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_name")]
        public string lot_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// productline_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_key")]
        public string productline_key { get; set; }
        /// <summary>
        /// productline_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_code")]
        public string productline_code { get; set; }
        /// <summary>
        /// productline_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_name")]
        public string productline_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// QPjudge_measures
        /// </summary>
        /// <returns></returns>
        [DisplayName("QPjudge_measures")]
        public string QPjudge_measures { get; set; }
        /// <summary>
        /// is_ProductOK
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_ProductOK")]
        public bool? is_ProductOK { get; set; }
        /// <summary>
        /// ProductOK_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductOK_time")]
        public DateTime? ProductOK_time { get; set; }
        /// <summary>
        /// is_repair
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_repair")]
        public bool? is_repair { get; set; }
        /// <summary>
        /// is_repair_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_repair_time")]
        public DateTime? is_repair_time { get; set; }
        /// <summary>
        /// repair_infor
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_infor")]
        public string repair_infor { get; set; }
        /// <summary>
        /// problem_description
        /// </summary>
        /// <returns></returns>
        [DisplayName("problem_description")]
        public string problem_description { get; set; }
        /// <summary>
        /// QP_task_launch_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_task_launch_time")]
        public DateTime? QP_task_launch_time { get; set; }
        /// <summary>
        /// QP_state
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_state")]
        public string QP_state { get; set; }
        /// <summary>
        /// length_of_solve
        /// </summary>
        /// <returns></returns>
        [DisplayName("length_of_solve")]
        public string length_of_solve { get; set; }
        /// <summary>
        /// length_of_fault
        /// </summary>
        /// <returns></returns>
        [DisplayName("length_of_fault")]
        public string length_of_fault { get; set; }
        /// <summary>
        /// QP_result
        /// </summary>
        /// <returns></returns>
        [DisplayName("QP_result")]
        public string QP_result { get; set; }
        /// <summary>
        /// QPjudge_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("QPjudge_time")]
        public DateTime? QPjudge_time { get; set; }
        /// <summary>
        /// UserSure_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("UserSure_time")]
        public DateTime? UserSure_time { get; set; }
        /// <summary>
        /// inputData_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("inputData_time")]
        public DateTime? inputData_time { get; set; }
        /// <summary>
        /// imagepath
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagepath")]
        public string imagepath { get; set; }
        /// <summary>
        /// imagefile
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagefile")]
        public string imagefile { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.key = KeyValue;
                                            }
        #endregion
    }
}