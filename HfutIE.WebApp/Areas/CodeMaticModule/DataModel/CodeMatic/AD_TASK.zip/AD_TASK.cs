//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_TASK
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.09.14 10:18</date>
    /// </author>
    /// </summary>
    [Description("AD_TASK")]
    [PrimaryKey("id")]
    public class AD_TASK : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// pushlevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("pushlevel")]
        public string pushlevel { get; set; }
        /// <summary>
        /// task_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_type")]
        public string task_type { get; set; }
        /// <summary>
        /// task_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_time")]
        public string task_time { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// task_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_code")]
        public string task_code { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// id
        /// </summary>
        /// <returns></returns>
        [DisplayName("id")]
        public string id { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.id = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.id = KeyValue;
                                            }
        #endregion
    }
}