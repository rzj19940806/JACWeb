//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// PRODUCT_STORAGE_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.31 10:00</date>
    /// </author>
    /// </summary>
    public class PRODUCT_STORAGE_INFORBll : RepositoryFactory<PRODUCT_STORAGE_INFOR>
    {
    }
}