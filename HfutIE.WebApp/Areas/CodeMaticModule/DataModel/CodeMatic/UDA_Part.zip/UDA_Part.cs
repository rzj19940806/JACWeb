//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// UDA_Part
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.06.05 16:34</date>
    /// </author>
    /// </summary>
    [Description("UDA_Part")]
    [PrimaryKey("object_key")]
    public class UDA_Part : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// object_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("object_key")]
        public string object_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("list_key")]
        public string list_key { get; set; }
        /// <summary>
        /// property1_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("property1_S")]
        public string property1_S { get; set; }
        /// <summary>
        /// route_30
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_30")]
        public string route_30 { get; set; }
        /// <summary>
        /// part_mc_u_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_mc_u_S")]
        public string part_mc_u_S { get; set; }
        /// <summary>
        /// part_model_no_u_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_model_no_u_S")]
        public string part_model_no_u_S { get; set; }
        /// <summary>
        /// part_type_u_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_type_u_S")]
        public string part_type_u_S { get; set; }
        /// <summary>
        /// part_struct_no_u_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_struct_no_u_S")]
        public string part_struct_no_u_S { get; set; }
        /// <summary>
        /// part_abb_u_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_abb_u_S")]
        public string part_abb_u_S { get; set; }
        /// <summary>
        /// part_draw_no_u_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_draw_no_u_S")]
        public string part_draw_no_u_S { get; set; }
        /// <summary>
        /// equip_program_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_program_code_S")]
        public string equip_program_code_S { get; set; }
        /// <summary>
        /// track_mode_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("track_mode_I")]
        public string track_mode_I { get; set; }
        /// <summary>
        /// part_base_type_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_base_type_S")]
        public string part_base_type_S { get; set; }
        /// <summary>
        /// tcu_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("tcu_code_S")]
        public string tcu_code_S { get; set; }
        /// <summary>
        /// spc_monitor_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("spc_monitor_S")]
        public string spc_monitor_S { get; set; }
        /// <summary>
        /// Item_1_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("Item_1_S")]
        public string Item_1_S { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.object_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.object_key = KeyValue;
                                            }
        #endregion
    }
}