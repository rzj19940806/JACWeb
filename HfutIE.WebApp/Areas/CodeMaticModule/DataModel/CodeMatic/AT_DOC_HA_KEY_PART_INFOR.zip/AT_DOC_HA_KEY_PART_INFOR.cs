//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2019
// Software Developers @ HfutIE 2019
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AT_DOC_HA_KEY_PART_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2019.01.08 12:22</date>
    /// </author>
    /// </summary>
    [Description("AT_DOC_HA_KEY_PART_INFOR")]
    [PrimaryKey("atr_key")]
    public class AT_DOC_HA_KEY_PART_INFOR : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// atr_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("atr_key")]
        public string atr_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// atr_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("atr_name")]
        public string atr_name { get; set; }
        /// <summary>
        /// purge_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("purge_status")]
        public int? purge_status { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creation_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_u")]
        public DateTime? creation_time_u { get; set; }
        /// <summary>
        /// creation_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_z")]
        public string creation_time_z { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// parent_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("parent_key")]
        public string parent_key { get; set; }
        /// <summary>
        /// account_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("account_code_S")]
        public string account_code_S { get; set; }
        /// <summary>
        /// account_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("account_name_S")]
        public string account_name_S { get; set; }
        /// <summary>
        /// addr_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_key_I")]
        public string addr_key_I { get; set; }
        /// <summary>
        /// addr_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_name_S")]
        public string addr_name_S { get; set; }
        /// <summary>
        /// addr_path_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_path_S")]
        public string addr_path_S { get; set; }
        /// <summary>
        /// area_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code_S")]
        public string area_code_S { get; set; }
        /// <summary>
        /// area_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key_I")]
        public string area_key_I { get; set; }
        /// <summary>
        /// area_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name_S")]
        public string area_name_S { get; set; }
        /// <summary>
        /// assembly_date_T
        /// </summary>
        /// <returns></returns>
        [DisplayName("assembly_date_T")]
        public DateTime? assembly_date_T { get; set; }
        /// <summary>
        /// assembly_date_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("assembly_date_u")]
        public DateTime? assembly_date_u { get; set; }
        /// <summary>
        /// assembly_date_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("assembly_date_z")]
        public string assembly_date_z { get; set; }
        /// <summary>
        /// assembly_time_T
        /// </summary>
        /// <returns></returns>
        [DisplayName("assembly_time_T")]
        public DateTime? assembly_time_T { get; set; }
        /// <summary>
        /// assembly_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("assembly_time_u")]
        public DateTime? assembly_time_u { get; set; }
        /// <summary>
        /// assembly_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("assembly_time_z")]
        public string assembly_time_z { get; set; }
        /// <summary>
        /// check_result_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_result_S")]
        public string check_result_S { get; set; }
        /// <summary>
        /// check_time_T
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_time_T")]
        public DateTime? check_time_T { get; set; }
        /// <summary>
        /// check_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_time_u")]
        public DateTime? check_time_u { get; set; }
        /// <summary>
        /// check_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_time_z")]
        public string check_time_z { get; set; }
        /// <summary>
        /// lower_body_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("lower_body_code_S")]
        public string lower_body_code_S { get; set; }
        /// <summary>
        /// equip_program_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_program_code_S")]
        public string equip_program_code_S { get; set; }
        /// <summary>
        /// order_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("order_code_S")]
        public string order_code_S { get; set; }
        /// <summary>
        /// p_line_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code_S")]
        public string p_line_code_S { get; set; }
        /// <summary>
        /// p_line_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key_I")]
        public string p_line_key_I { get; set; }
        /// <summary>
        /// p_line_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name_S")]
        public string p_line_name_S { get; set; }
        /// <summary>
        /// part_barcode_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_barcode_S")]
        public string part_barcode_S { get; set; }
        /// <summary>
        /// part_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_code_S")]
        public string part_code_S { get; set; }
        /// <summary>
        /// part_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key_I")]
        public string part_key_I { get; set; }
        /// <summary>
        /// part_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name_S")]
        public string part_name_S { get; set; }
        /// <summary>
        /// plan_no_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_no_I")]
        public string plan_no_I { get; set; }
        /// <summary>
        /// plan_num_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_num_I")]
        public string plan_num_I { get; set; }
        /// <summary>
        /// product_abb_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb_S")]
        public string product_abb_S { get; set; }
        /// <summary>
        /// product_batch_no_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_batch_no_S")]
        public string product_batch_no_S { get; set; }
        /// <summary>
        /// upper_body_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("upper_body_code_S")]
        public string upper_body_code_S { get; set; }
        /// <summary>
        /// product_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code_S")]
        public string product_code_S { get; set; }
        /// <summary>
        /// product_draw_no_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no_S")]
        public string product_draw_no_S { get; set; }
        /// <summary>
        /// product_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_key_I")]
        public string product_key_I { get; set; }
        /// <summary>
        /// product_model_no_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no_S")]
        public string product_model_no_S { get; set; }
        /// <summary>
        /// product_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name_S")]
        public string product_name_S { get; set; }
        /// <summary>
        /// product_serial_no_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_serial_no_S")]
        public string product_serial_no_S { get; set; }
        /// <summary>
        /// product_struct_no_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no_S")]
        public string product_struct_no_S { get; set; }
        /// <summary>
        /// product_type_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type_S")]
        public string product_type_S { get; set; }
        /// <summary>
        /// quantity_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("quantity_I")]
        public string quantity_I { get; set; }
        /// <summary>
        /// remarks_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks_S")]
        public string remarks_S { get; set; }
        /// <summary>
        /// site_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_code_S")]
        public string site_code_S { get; set; }
        /// <summary>
        /// site_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_key_I")]
        public string site_key_I { get; set; }
        /// <summary>
        /// site_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_name_S")]
        public string site_name_S { get; set; }
        /// <summary>
        /// special_remarks_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("special_remarks_S")]
        public string special_remarks_S { get; set; }
        /// <summary>
        /// supplier_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_code_S")]
        public string supplier_code_S { get; set; }
        /// <summary>
        /// supplier_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_key_I")]
        public string supplier_key_I { get; set; }
        /// <summary>
        /// supplier_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_name_S")]
        public string supplier_name_S { get; set; }
        /// <summary>
        /// user_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_code_S")]
        public string user_code_S { get; set; }
        /// <summary>
        /// user_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_key_I")]
        public string user_key_I { get; set; }
        /// <summary>
        /// user_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_name_S")]
        public string user_name_S { get; set; }
        /// <summary>
        /// wc_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code_S")]
        public string wc_code_S { get; set; }
        /// <summary>
        /// wc_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key_I")]
        public string wc_key_I { get; set; }
        /// <summary>
        /// wc_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name_S")]
        public string wc_name_S { get; set; }
        /// <summary>
        /// wo_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("wo_code_S")]
        public string wo_code_S { get; set; }
        /// <summary>
        /// woi_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("woi_code_S")]
        public string woi_code_S { get; set; }
        /// <summary>
        /// pro_born_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_born_code_S")]
        public string pro_born_code_S { get; set; }
        /// <summary>
        /// state_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("state_S")]
        public string state_S { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.atr_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.atr_key = KeyValue;
                                            }
        #endregion
    }
}