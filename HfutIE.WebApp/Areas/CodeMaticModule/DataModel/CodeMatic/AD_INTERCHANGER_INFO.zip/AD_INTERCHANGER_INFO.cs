//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_INTERCHANGER_INFO
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.18 09:24</date>
    /// </author>
    /// </summary>
    [Description("AD_INTERCHANGER_INFO")]
    [PrimaryKey("interchanger_key")]
    public class AD_INTERCHANGER_INFO : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// interchanger_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("interchanger_key")]
        public string interchanger_key { get; set; }
        /// <summary>
        /// interchanger_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("interchanger_code")]
        public string interchanger_code { get; set; }
        /// <summary>
        /// interchanger_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("interchanger_name")]
        public string interchanger_name { get; set; }
        /// <summary>
        /// interchanger_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("interchanger_type")]
        public string interchanger_type { get; set; }
        /// <summary>
        /// access_quantity
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_quantity")]
        public string access_quantity { get; set; }
        /// <summary>
        /// use_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("use_time")]
        public DateTime? use_time { get; set; }
        /// <summary>
        /// arrange_location
        /// </summary>
        /// <returns></returns>
        [DisplayName("arrange_location")]
        public string arrange_location { get; set; }
        /// <summary>
        /// supplier
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier")]
        public string supplier { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.interchanger_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.interchanger_key = KeyValue;
                                            }
        #endregion
    }
}