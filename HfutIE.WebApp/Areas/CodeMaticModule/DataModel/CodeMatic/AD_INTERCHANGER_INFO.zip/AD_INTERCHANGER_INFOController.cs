using HfutIE.Business;
using HfutIE.Entity;
using HfutIE.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HfutIE.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// AD_INTERCHANGER_INFO������
    /// </summary>
    public class AD_INTERCHANGER_INFOController : PublicController<AD_INTERCHANGER_INFO>
    {
    }
}