//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_INTERCHANGER_INFO
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.18 09:24</date>
    /// </author>
    /// </summary>
    public class AD_INTERCHANGER_INFOBll : RepositoryFactory<AD_INTERCHANGER_INFO>
    {
    }
}