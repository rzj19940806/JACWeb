//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// DCS_PARM
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.18 18:12</date>
    /// </author>
    /// </summary>
    [Description("DCS_PARM")]
    [PrimaryKey("dcs_key")]
    public class DCS_PARM : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// dcs_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("dcs_key")]
        public string dcs_key { get; set; }
        /// <summary>
        /// parm
        /// </summary>
        /// <returns></returns>
        [DisplayName("parm")]
        public string parm { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// type
        /// </summary>
        /// <returns></returns>
        [DisplayName("type")]
        public string type { get; set; }
        /// <summary>
        /// description
        /// </summary>
        /// <returns></returns>
        [DisplayName("description")]
        public string description { get; set; }
        /// <summary>
        /// category
        /// </summary>
        /// <returns></returns>
        [DisplayName("category")]
        public string category { get; set; }
        /// <summary>
        /// image_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("image_key")]
        public string image_key { get; set; }
        /// <summary>
        /// text_length
        /// </summary>
        /// <returns></returns>
        [DisplayName("text_length")]
        public int? text_length { get; set; }
        /// <summary>
        /// text_mask
        /// </summary>
        /// <returns></returns>
        [DisplayName("text_mask")]
        public string text_mask { get; set; }
        /// <summary>
        /// upper_boundary
        /// </summary>
        /// <returns></returns>
        [DisplayName("upper_boundary")]
        public Single? upper_boundary { get; set; }
        /// <summary>
        /// upper_spec
        /// </summary>
        /// <returns></returns>
        [DisplayName("upper_spec")]
        public Single? upper_spec { get; set; }
        /// <summary>
        /// upper_control
        /// </summary>
        /// <returns></returns>
        [DisplayName("upper_control")]
        public Single? upper_control { get; set; }
        /// <summary>
        /// target
        /// </summary>
        /// <returns></returns>
        [DisplayName("target")]
        public Single? target { get; set; }
        /// <summary>
        /// lower_control
        /// </summary>
        /// <returns></returns>
        [DisplayName("lower_control")]
        public Single? lower_control { get; set; }
        /// <summary>
        /// lower_spec
        /// </summary>
        /// <returns></returns>
        [DisplayName("lower_spec")]
        public Single? lower_spec { get; set; }
        /// <summary>
        /// lower_boundary
        /// </summary>
        /// <returns></returns>
        [DisplayName("lower_boundary")]
        public Single? lower_boundary { get; set; }
        /// <summary>
        /// prompt
        /// </summary>
        /// <returns></returns>
        [DisplayName("prompt")]
        public string prompt { get; set; }
        /// <summary>
        /// mandatory
        /// </summary>
        /// <returns></returns>
        [DisplayName("mandatory")]
        public int? mandatory { get; set; }
        /// <summary>
        /// inst_list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("inst_list_key")]
        public string inst_list_key { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.dcs_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.dcs_key = KeyValue;
                                            }
        #endregion
    }
}