//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Tool_Turn_Comp
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.01.31 09:24</date>
    /// </author>
    /// </summary>
    [Description("AD_Tool_Turn_Comp")]
    [PrimaryKey("comp_key")]
    public class AD_Tool_Turn_Comp : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// comp_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("comp_key")]
        public string comp_key { get; set; }
        /// <summary>
        /// up_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_key")]
        public string up_key { get; set; }
        /// <summary>
        /// ZRA_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("ZRA_value")]
        public string ZRA_value { get; set; }
        /// <summary>
        /// XRA_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("XRA_value")]
        public string XRA_value { get; set; }
        /// <summary>
        /// Ra_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ra_value")]
        public string Ra_value { get; set; }
        /// <summary>
        /// angle1_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("angle1_value")]
        public string angle1_value { get; set; }
        /// <summary>
        /// angle2_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("angle2_value")]
        public string angle2_value { get; set; }
        /// <summary>
        /// fringe_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("fringe_value")]
        public string fringe_value { get; set; }
        /// <summary>
        /// diameter_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("diameter_value")]
        public string diameter_value { get; set; }
        /// <summary>
        /// comp_content
        /// </summary>
        /// <returns></returns>
        [DisplayName("comp_content")]
        public string comp_content { get; set; }
        /// <summary>
        /// recode_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("recode_time")]
        public DateTime? recode_time { get; set; }
        /// <summary>
        /// comp_man_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("comp_man_key")]
        public string comp_man_key { get; set; }
        /// <summary>
        /// comp_man_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("comp_man_code")]
        public string comp_man_code { get; set; }
        /// <summary>
        /// comp_man_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("comp_man_name")]
        public string comp_man_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.comp_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.comp_key = KeyValue;
                                            }
        #endregion
    }
}