using HfutIE.Business;
using HfutIE.Entity;
using HfutIE.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HfutIE.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// AD_ER_PART������
    /// </summary>
    public class AD_ER_PARTController : PublicController<AD_ER_PART>
    {
    }
}