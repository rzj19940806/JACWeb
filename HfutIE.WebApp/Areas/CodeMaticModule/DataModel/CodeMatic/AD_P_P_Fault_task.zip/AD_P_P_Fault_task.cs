//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_P_Fault_task
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.14 20:19</date>
    /// </author>
    /// </summary>
    [Description("AD_P_P_Fault_task")]
    [PrimaryKey("P_Fault_task_key")]
    public class AD_P_P_Fault_task : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// P_Fault_task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_Fault_task_key")]
        public string P_Fault_task_key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// qptask_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("qptask_key")]
        public string qptask_key { get; set; }
        /// <summary>
        /// qptask_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("qptask_code")]
        public string qptask_code { get; set; }
        /// <summary>
        /// lot_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_name")]
        public string lot_name { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// product_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name")]
        public string product_name { get; set; }
        /// <summary>
        /// product_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type")]
        public string product_type { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// product_struct_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// product_abb
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_born_code")]
        public string product_born_code { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// fault_start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_start_time")]
        public string fault_start_time { get; set; }
        /// <summary>
        /// fault_end_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_end_time")]
        public string fault_end_time { get; set; }
        /// <summary>
        /// apply_workshop
        /// </summary>
        /// <returns></returns>
        [DisplayName("apply_workshop")]
        public string apply_workshop { get; set; }
        /// <summary>
        /// repair_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_type")]
        public string repair_type { get; set; }
        /// <summary>
        /// fault_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_status")]
        public string fault_status { get; set; }
        /// <summary>
        /// P_Fault_task_result
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_Fault_task_result")]
        public string P_Fault_task_result { get; set; }
        /// <summary>
        /// downline_wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("downline_wc_key")]
        public string downline_wc_key { get; set; }
        /// <summary>
        /// downline_wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("downline_wc_code")]
        public string downline_wc_code { get; set; }
        /// <summary>
        /// downline_wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("downline_wc_name")]
        public string downline_wc_name { get; set; }
        /// <summary>
        /// online_wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("online_wc_key")]
        public string online_wc_key { get; set; }
        /// <summary>
        /// online_wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("online_wc_code")]
        public string online_wc_code { get; set; }
        /// <summary>
        /// online_wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("online_wc_name")]
        public string online_wc_name { get; set; }
        /// <summary>
        /// type
        /// </summary>
        /// <returns></returns>
        [DisplayName("type")]
        public string type { get; set; }
        /// <summary>
        /// starter_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("starter_key")]
        public string starter_key { get; set; }
        /// <summary>
        /// starter_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("starter_code")]
        public string starter_code { get; set; }
        /// <summary>
        /// starter_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("starter_name")]
        public string starter_name { get; set; }
        /// <summary>
        /// repair_usekey
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_usekey")]
        public string repair_usekey { get; set; }
        /// <summary>
        /// repair_usercode
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_usercode")]
        public string repair_usercode { get; set; }
        /// <summary>
        /// repair_username
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_username")]
        public string repair_username { get; set; }
        /// <summary>
        /// repair_starttime
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_starttime")]
        public DateTime? repair_starttime { get; set; }
        /// <summary>
        /// inputdata_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("inputdata_time")]
        public DateTime? inputdata_time { get; set; }
        /// <summary>
        /// repair_endtime
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_endtime")]
        public DateTime? repair_endtime { get; set; }
        /// <summary>
        /// usersure_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("usersure_time")]
        public DateTime? usersure_time { get; set; }
        /// <summary>
        /// fault_decription
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_decription")]
        public string fault_decription { get; set; }
        /// <summary>
        /// fault_case
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_case")]
        public string fault_case { get; set; }
        /// <summary>
        /// solving_measures
        /// </summary>
        /// <returns></returns>
        [DisplayName("solving_measures")]
        public string solving_measures { get; set; }
        /// <summary>
        /// S_solving_measures
        /// </summary>
        /// <returns></returns>
        [DisplayName("S_solving_measures")]
        public string S_solving_measures { get; set; }
        /// <summary>
        /// disposal_measures
        /// </summary>
        /// <returns></returns>
        [DisplayName("disposal_measures")]
        public string disposal_measures { get; set; }
        /// <summary>
        /// test_result
        /// </summary>
        /// <returns></returns>
        [DisplayName("test_result")]
        public string test_result { get; set; }
        /// <summary>
        /// imagefile
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagefile")]
        public string imagefile { get; set; }
        /// <summary>
        /// imagepath
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagepath")]
        public string imagepath { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// eqm_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_key")]
        public string eqm_key { get; set; }
        /// <summary>
        /// eqm_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_code")]
        public string eqm_code { get; set; }
        /// <summary>
        /// eqm_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_name")]
        public string eqm_name { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creator_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_code")]
        public string creator_code { get; set; }
        /// <summary>
        /// creator_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_name")]
        public string creator_name { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// modifier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_code")]
        public string modifier_code { get; set; }
        /// <summary>
        /// modifier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_name")]
        public string modifier_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.P_Fault_task_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.P_Fault_task_key = KeyValue;
                                            }
        #endregion
    }
}