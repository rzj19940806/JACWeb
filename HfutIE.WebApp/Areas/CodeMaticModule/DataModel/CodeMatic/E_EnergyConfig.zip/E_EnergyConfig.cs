//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2021
// Software Developers @ HfutIE 2021
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// �����ܺ����ñ�
    /// <author>
    ///		<name>she</name>
    ///		<date>2021.08.28 16:45</date>
    /// </author>
    /// </summary>
    [Description("�����ܺ����ñ�")]
    [PrimaryKey("����")]
    public class E_EnergyConfig : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// PowerId
        /// </summary>
        /// <returns></returns>
        [DisplayName("PowerId")]
        public string ���� { get; set; }
        /// <summary>
        /// Class
        /// </summary>
        /// <returns></returns>
        [DisplayName("Class")]
        public string ���������� { get; set; }
        /// <summary>
        /// ClassId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ClassId")]
        public string ������ID { get; set; }
        /// <summary>
        /// Class
        /// </summary>
        /// <returns></returns>
        [DisplayName("Class")]
        public string �ӻ������� { get; set; }
        /// <summary>
        /// ClassId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ClassId")]
        public string �ӻ���ID { get; set; }
        /// <summary>
        /// EnergyNm
        /// </summary>
        /// <returns></returns>
        [DisplayName("EnergyNm")]
        public string �ܺ����� { get; set; }
        /// <summary>
        /// EnergyProp
        /// </summary>
        /// <returns></returns>
        [DisplayName("EnergyProp")]
        public string �ܺ�ռ�� { get; set; }
        /// <summary>
        /// Enabled
        /// </summary>
        /// <returns></returns>
        [DisplayName("Enabled")]
        public string ��Ч�� { get; set; }
        /// <summary>
        /// CreTm
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreTm")]
        public DateTime? ����ʱ�� { get; set; }
        /// <summary>
        /// CreCd
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreCd")]
        public string �����˱�� { get; set; }
        /// <summary>
        /// CreNm
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreNm")]
        public string ���������� { get; set; }
        /// <summary>
        /// MdfTm
        /// </summary>
        /// <returns></returns>
        [DisplayName("MdfTm")]
        public DateTime? �޸�ʱ�� { get; set; }
        /// <summary>
        /// MdfCd
        /// </summary>
        /// <returns></returns>
        [DisplayName("MdfCd")]
        public string �޸��˱�� { get; set; }
        /// <summary>
        /// MdfNm
        /// </summary>
        /// <returns></returns>
        [DisplayName("MdfNm")]
        public string �޸������� { get; set; }
        /// <summary>
        /// Rem
        /// </summary>
        /// <returns></returns>
        [DisplayName("Rem")]
        public string ��ע { get; set; }
        /// <summary>
        /// RsvFld1
        /// </summary>
        /// <returns></returns>
        [DisplayName("RsvFld1")]
        public string Ԥ���ֶ�1 { get; set; }
        /// <summary>
        /// RsvFld2
        /// </summary>
        /// <returns></returns>
        [DisplayName("RsvFld2")]
        public string Ԥ���ֶ�2 { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.���� = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.���� = KeyValue;
                                            }
        #endregion
    }
}