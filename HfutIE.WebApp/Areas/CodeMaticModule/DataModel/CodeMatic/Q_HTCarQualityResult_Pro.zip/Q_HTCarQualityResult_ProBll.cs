//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2022
// Software Developers @ HfutIE 2022
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// �庸Ϳװ�ʼ�����¼���̱�
    /// <author>
    ///		<name>she</name>
    ///		<date>2022.04.25 09:54</date>
    /// </author>
    /// </summary>
    public class Q_HTCarQualityResult_ProBll : RepositoryFactory<Q_HTCarQualityResult_Pro>
    {
    }
}