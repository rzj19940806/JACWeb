//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_DOC_S_Che_Task
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.11 09:51</date>
    /// </author>
    /// </summary>
    [Description("AD_DOC_S_Che_Task")]
    [PrimaryKey("S_Che_T_key")]
    public class AD_DOC_S_Che_Task : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// S_Che_T_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("S_Che_T_key")]
        public string S_Che_T_key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// S_Che_T_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("S_Che_T_code")]
        public string S_Che_T_code { get; set; }
        /// <summary>
        /// S_Che_T_result
        /// </summary>
        /// <returns></returns>
        [DisplayName("S_Che_T_result")]
        public string S_Che_T_result { get; set; }
        /// <summary>
        /// S_Che_T_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("S_Che_T_status")]
        public string S_Che_T_status { get; set; }
        /// <summary>
        /// P_S_Che_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_S_Che_name")]
        public string P_S_Che_name { get; set; }
        /// <summary>
        /// P_S_Che_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_S_Che_code")]
        public string P_S_Che_code { get; set; }
        /// <summary>
        /// P_S_Che_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_S_Che_key")]
        public string P_S_Che_key { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// eqm_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_key")]
        public string eqm_key { get; set; }
        /// <summary>
        /// eqm_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_code")]
        public string eqm_code { get; set; }
        /// <summary>
        /// eqm_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_name")]
        public string eqm_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.S_Che_T_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.S_Che_T_key = KeyValue;
                                            }
        #endregion
    }
}