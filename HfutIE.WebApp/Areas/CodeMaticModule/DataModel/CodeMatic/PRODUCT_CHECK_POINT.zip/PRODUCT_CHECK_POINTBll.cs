//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// PRODUCT_CHECK_POINT
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.04.11 09:23</date>
    /// </author>
    /// </summary>
    public class PRODUCT_CHECK_POINTBll : RepositoryFactory<PRODUCT_CHECK_POINT>
    {
    }
}