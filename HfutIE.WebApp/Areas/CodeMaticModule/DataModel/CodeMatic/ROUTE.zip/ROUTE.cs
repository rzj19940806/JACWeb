//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// ROUTE
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.05.21 14:03</date>
    /// </author>
    /// </summary>
    [Description("ROUTE")]
    [PrimaryKey("route_name")]
    public class ROUTE : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// route_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_key")]
        public string route_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// route_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_name")]
        public string route_name { get; set; }
        /// <summary>
        /// description
        /// </summary>
        /// <returns></returns>
        [DisplayName("description")]
        public string description { get; set; }
        /// <summary>
        /// category
        /// </summary>
        /// <returns></returns>
        [DisplayName("category")]
        public string category { get; set; }
        /// <summary>
        /// cache_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("cache_id")]
        public int? cache_id { get; set; }
        /// <summary>
        /// image_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("image_key")]
        public string image_key { get; set; }
        /// <summary>
        /// state
        /// </summary>
        /// <returns></returns>
        [DisplayName("state")]
        public string state { get; set; }
        /// <summary>
        /// inst_list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("inst_list_key")]
        public string inst_list_key { get; set; }
        /// <summary>
        /// form_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("form_key")]
        public string form_key { get; set; }
        /// <summary>
        /// icon_size
        /// </summary>
        /// <returns></returns>
        [DisplayName("icon_size")]
        public int? icon_size { get; set; }
        /// <summary>
        /// enforcement
        /// </summary>
        /// <returns></returns>
        [DisplayName("enforcement")]
        public int? enforcement { get; set; }
        /// <summary>
        /// reasons
        /// </summary>
        /// <returns></returns>
        [DisplayName("reasons")]
        public string reasons { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creation_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_u")]
        public DateTime? creation_time_u { get; set; }
        /// <summary>
        /// creation_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_z")]
        public string creation_time_z { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// version
        /// </summary>
        /// <returns></returns>
        [DisplayName("version")]
        public int? version { get; set; }
        /// <summary>
        /// access_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_level")]
        public int? access_level { get; set; }
        /// <summary>
        /// checkout_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("checkout_user_key")]
        public string checkout_user_key { get; set; }
        /// <summary>
        /// uda_0
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_0")]
        public string uda_0 { get; set; }
        /// <summary>
        /// uda_1
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_1")]
        public string uda_1 { get; set; }
        /// <summary>
        /// uda_2
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_2")]
        public string uda_2 { get; set; }
        /// <summary>
        /// uda_3
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_3")]
        public string uda_3 { get; set; }
        /// <summary>
        /// uda_4
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_4")]
        public string uda_4 { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// update_privilege_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("update_privilege_key")]
        public string update_privilege_key { get; set; }
        /// <summary>
        /// delete_privilege_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("delete_privilege_key")]
        public string delete_privilege_key { get; set; }
        /// <summary>
        /// effectivity_start
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_start")]
        public DateTime? effectivity_start { get; set; }
        /// <summary>
        /// effectivity_start_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_start_u")]
        public DateTime? effectivity_start_u { get; set; }
        /// <summary>
        /// effectivity_start_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_start_z")]
        public string effectivity_start_z { get; set; }
        /// <summary>
        /// effectivity_end
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_end")]
        public DateTime? effectivity_end { get; set; }
        /// <summary>
        /// effectivity_end_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_end_u")]
        public DateTime? effectivity_end_u { get; set; }
        /// <summary>
        /// effectivity_end_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_end_z")]
        public string effectivity_end_z { get; set; }
        /// <summary>
        /// route_revision
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_revision")]
        public string route_revision { get; set; }
        /// <summary>
        /// route_ext_revision
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_ext_revision")]
        public string route_ext_revision { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.route_name = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.route_name = KeyValue;
                                            }
        #endregion
    }
}