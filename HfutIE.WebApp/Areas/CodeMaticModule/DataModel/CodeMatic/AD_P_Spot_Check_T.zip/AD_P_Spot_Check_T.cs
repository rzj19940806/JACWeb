//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_Spot_Check_T
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.13 10:18</date>
    /// </author>
    /// </summary>
    [Description("AD_P_Spot_Check_T")]
    [PrimaryKey("key")]
    public class AD_P_Spot_Check_T : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// key
        /// </summary>
        /// <returns></returns>
        [DisplayName("key")]
        public string key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// task_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_code")]
        public string task_code { get; set; }
        /// <summary>
        /// task_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_name")]
        public string task_name { get; set; }
        /// <summary>
        /// check_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_user_key")]
        public string check_user_key { get; set; }
        /// <summary>
        /// check_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_user_code")]
        public string check_user_code { get; set; }
        /// <summary>
        /// check_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_user_name")]
        public string check_user_name { get; set; }
        /// <summary>
        /// part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key")]
        public string part_key { get; set; }
        /// <summary>
        /// part_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_draw_no")]
        public string part_draw_no { get; set; }
        /// <summary>
        /// part_mc
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_mc")]
        public string part_mc { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// check_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_time")]
        public DateTime? check_time { get; set; }
        /// <summary>
        /// start_check_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_check_time")]
        public DateTime? start_check_time { get; set; }
        /// <summary>
        /// end_check_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("end_check_time")]
        public DateTime? end_check_time { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creator_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_code")]
        public string creator_code { get; set; }
        /// <summary>
        /// creator_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_name")]
        public string creator_name { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// modifier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_code")]
        public string modifier_code { get; set; }
        /// <summary>
        /// modifier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_name")]
        public string modifier_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.key = KeyValue;
                                            }
        #endregion
    }
}