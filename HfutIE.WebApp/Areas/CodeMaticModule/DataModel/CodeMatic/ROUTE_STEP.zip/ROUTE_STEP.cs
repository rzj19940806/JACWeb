//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// ROUTE_STEP
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.05.21 14:00</date>
    /// </author>
    /// </summary>
    [Description("ROUTE_STEP")]
    [PrimaryKey("route_key")]
    public class ROUTE_STEP : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// route_step_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_step_key")]
        public string route_step_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// route_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_key")]
        public string route_key { get; set; }
        /// <summary>
        /// op_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("op_key")]
        public string op_key { get; set; }
        /// <summary>
        /// route_step_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_step_name")]
        public string route_step_name { get; set; }
        /// <summary>
        /// route_step_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("route_step_type")]
        public string route_step_type { get; set; }
        /// <summary>
        /// description
        /// </summary>
        /// <returns></returns>
        [DisplayName("description")]
        public string description { get; set; }
        /// <summary>
        /// category
        /// </summary>
        /// <returns></returns>
        [DisplayName("category")]
        public string category { get; set; }
        /// <summary>
        /// pixel_x
        /// </summary>
        /// <returns></returns>
        [DisplayName("pixel_x")]
        public int? pixel_x { get; set; }
        /// <summary>
        /// pixel_y
        /// </summary>
        /// <returns></returns>
        [DisplayName("pixel_y")]
        public int? pixel_y { get; set; }
        /// <summary>
        /// inst_list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("inst_list_key")]
        public string inst_list_key { get; set; }
        /// <summary>
        /// dcs_list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("dcs_list_key")]
        public string dcs_list_key { get; set; }
        /// <summary>
        /// form_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("form_key")]
        public string form_key { get; set; }
        /// <summary>
        /// label_width
        /// </summary>
        /// <returns></returns>
        [DisplayName("label_width")]
        public int? label_width { get; set; }
        /// <summary>
        /// border_flag
        /// </summary>
        /// <returns></returns>
        [DisplayName("border_flag")]
        public int? border_flag { get; set; }
        /// <summary>
        /// checklist_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("checklist_key")]
        public string checklist_key { get; set; }
        /// <summary>
        /// dependencies
        /// </summary>
        /// <returns></returns>
        [DisplayName("dependencies")]
        public string dependencies { get; set; }
        /// <summary>
        /// enforcement
        /// </summary>
        /// <returns></returns>
        [DisplayName("enforcement")]
        public int? enforcement { get; set; }
        /// <summary>
        /// reasons
        /// </summary>
        /// <returns></returns>
        [DisplayName("reasons")]
        public string reasons { get; set; }
        /// <summary>
        /// cycle_duration
        /// </summary>
        /// <returns></returns>
        [DisplayName("cycle_duration")]
        public int? cycle_duration { get; set; }
        /// <summary>
        /// cycle_duration_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("cycle_duration_type")]
        public int? cycle_duration_type { get; set; }
        /// <summary>
        /// failure
        /// </summary>
        /// <returns></returns>
        [DisplayName("failure")]
        public int? failure { get; set; }
        /// <summary>
        /// value_added
        /// </summary>
        /// <returns></returns>
        [DisplayName("value_added")]
        public int? value_added { get; set; }
        /// <summary>
        /// work_center_assigned
        /// </summary>
        /// <returns></returns>
        [DisplayName("work_center_assigned")]
        public int? work_center_assigned { get; set; }
        /// <summary>
        /// uda_0
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_0")]
        public string uda_0 { get; set; }
        /// <summary>
        /// uda_1
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_1")]
        public string uda_1 { get; set; }
        /// <summary>
        /// uda_2
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_2")]
        public string uda_2 { get; set; }
        /// <summary>
        /// uda_3
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_3")]
        public string uda_3 { get; set; }
        /// <summary>
        /// uda_4
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_4")]
        public string uda_4 { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.route_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.route_key = KeyValue;
                                            }
        #endregion
    }
}