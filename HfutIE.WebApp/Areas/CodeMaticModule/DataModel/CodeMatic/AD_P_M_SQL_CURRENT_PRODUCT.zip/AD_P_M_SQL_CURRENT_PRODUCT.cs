//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_M_SQL_CURRENT_PRODUCT
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.24 17:03</date>
    /// </author>
    /// </summary>
    [Description("AD_P_M_SQL_CURRENT_PRODUCT")]
    [PrimaryKey("unit_key")]
    public class AD_P_M_SQL_CURRENT_PRODUCT : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// unit_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("unit_key")]
        public string unit_key { get; set; }
        /// <summary>
        /// serial_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("serial_number")]
        public string serial_number { get; set; }
        /// <summary>
        /// unit _description
        /// </summary>
        /// <returns></returns>
        [DisplayName("unit _description")]
        public string unit _description { get; set; }
        /// <summary>
        /// lot_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_key")]
        public string lot_key { get; set; }
        /// <summary>
        /// lot_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_code")]
        public string lot_code { get; set; }
        /// <summary>
        /// downloadstate
        /// </summary>
        /// <returns></returns>
        [DisplayName("downloadstate")]
        public string downloadstate { get; set; }
        /// <summary>
        /// product_batch_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_batch_no")]
        public string product_batch_no { get; set; }
        /// <summary>
        /// product_serial_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_serial_no")]
        public string product_serial_no { get; set; }
        /// <summary>
        /// is_repair
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_repair")]
        public int? is_repair { get; set; }
        /// <summary>
        /// repair_frequency
        /// </summary>
        /// <returns></returns>
        [DisplayName("repair_frequency")]
        public string repair_frequency { get; set; }
        /// <summary>
        /// is_online
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_online")]
        public int? is_online { get; set; }
        /// <summary>
        /// online_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("online_time")]
        public string online_time { get; set; }
        /// <summary>
        /// is_scraped
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_scraped")]
        public int? is_scraped { get; set; }
        /// <summary>
        /// no
        /// </summary>
        /// <returns></returns>
        [DisplayName("no")]
        public string no { get; set; }
        /// <summary>
        /// product_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_key")]
        public string product_key { get; set; }
        /// <summary>
        /// product_abb
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// product_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name")]
        public string product_name { get; set; }
        /// <summary>
        /// product_struct_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// product_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type")]
        public string product_type { get; set; }
        /// <summary>
        /// serial_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("serial_num")]
        public string serial_num { get; set; }
        /// <summary>
        /// special_remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("special_remarks")]
        public string special_remarks { get; set; }
        /// <summary>
        /// year
        /// </summary>
        /// <returns></returns>
        [DisplayName("year")]
        public string year { get; set; }
        /// <summary>
        /// month
        /// </summary>
        /// <returns></returns>
        [DisplayName("month")]
        public string month { get; set; }
        /// <summary>
        /// day
        /// </summary>
        /// <returns></returns>
        [DisplayName("day")]
        public string day { get; set; }
        /// <summary>
        /// plan_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_no")]
        public string plan_no { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.unit_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.unit_key = KeyValue;
                                            }
        #endregion
    }
}