//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_S_Che_Item_B
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.08.29 19:23</date>
    /// </author>
    /// </summary>
    [Description("AD_S_Che_Item_B")]
    [PrimaryKey("key")]
    public class AD_S_Che_Item_B : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// key
        /// </summary>
        /// <returns></returns>
        [DisplayName("key")]
        public string key { get; set; }
        /// <summary>
        /// s_che_item_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_code")]
        public string s_che_item_code { get; set; }
        /// <summary>
        /// s_che_item_mech
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_mech")]
        public string s_che_item_mech { get; set; }
        /// <summary>
        /// s_che_item_part
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_part")]
        public string s_che_item_part { get; set; }
        /// <summary>
        /// s_che_item_oper
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_oper")]
        public string s_che_item_oper { get; set; }
        /// <summary>
        /// s_che_item_stan
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_stan")]
        public string s_che_item_stan { get; set; }
        /// <summary>
        /// s_che_item_state
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_state")]
        public string s_che_item_state { get; set; }
        /// <summary>
        /// s_che_item_period
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_period")]
        public string s_che_item_period { get; set; }
        /// <summary>
        /// s_che_item_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_type")]
        public string s_che_item_type { get; set; }
        /// <summary>
        /// s_che_item_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("s_che_item_name")]
        public string s_che_item_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// eqm_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_key")]
        public string eqm_key { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.key = KeyValue;
                                            }
        #endregion
    }
}