//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// P_ANDON_MATERIAL_NEED
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.04 09:54</date>
    /// </author>
    /// </summary>
    public class P_ANDON_MATERIAL_NEEDBll : RepositoryFactory<P_ANDON_MATERIAL_NEED>
    {
    }
}