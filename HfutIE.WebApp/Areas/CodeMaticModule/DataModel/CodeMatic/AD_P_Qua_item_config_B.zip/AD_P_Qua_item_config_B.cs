//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_Qua_item_config_B
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.08.31 11:31</date>
    /// </author>
    /// </summary>
    [Description("AD_P_Qua_item_config_B")]
    [PrimaryKey("p_qua_item_config_key")]
    public class AD_P_Qua_item_config_B : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// p_qua_item_config_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_qua_item_config_key")]
        public string p_qua_item_config_key { get; set; }
        /// <summary>
        /// p_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_key")]
        public string p_key { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// qua_item_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("qua_item_key")]
        public string qua_item_key { get; set; }
        /// <summary>
        /// eqm_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_key")]
        public string eqm_key { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.p_qua_item_config_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.p_qua_item_config_key = KeyValue;
                                            }
        #endregion
    }
}