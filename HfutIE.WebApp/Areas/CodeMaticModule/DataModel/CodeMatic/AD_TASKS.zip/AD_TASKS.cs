//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_TASKS
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.10.13 20:29</date>
    /// </author>
    /// </summary>
    [Description("AD_TASKS")]
    [PrimaryKey("T_key")]
    public class AD_TASKS : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// T_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("T_key")]
        public string T_key { get; set; }
        /// <summary>
        /// task_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_code")]
        public string task_code { get; set; }
        /// <summary>
        /// task_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_name")]
        public string task_name { get; set; }
        /// <summary>
        /// task_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_type")]
        public string task_type { get; set; }
        /// <summary>
        /// status
        /// </summary>
        /// <returns></returns>
        [DisplayName("status")]
        public string status { get; set; }
        /// <summary>
        /// start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time")]
        public DateTime? start_time { get; set; }
        /// <summary>
        /// response_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("response_time")]
        public DateTime? response_time { get; set; }
        /// <summary>
        /// complete_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("complete_time")]
        public DateTime? complete_time { get; set; }
        /// <summary>
        /// verify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("verify_time")]
        public DateTime? verify_time { get; set; }
        /// <summary>
        /// end_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("end_time")]
        public DateTime? end_time { get; set; }
        /// <summary>
        /// response_person_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("response_person_key")]
        public string response_person_key { get; set; }
        /// <summary>
        /// response_person_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("response_person_code")]
        public string response_person_code { get; set; }
        /// <summary>
        /// response_person_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("response_person_name")]
        public string response_person_name { get; set; }
        /// <summary>
        /// start_person_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_person_key")]
        public string start_person_key { get; set; }
        /// <summary>
        /// start_person_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_person_code")]
        public string start_person_code { get; set; }
        /// <summary>
        /// start_person_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_person_name")]
        public string start_person_name { get; set; }
        /// <summary>
        /// verify_person_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("verify_person_key")]
        public string verify_person_key { get; set; }
        /// <summary>
        /// verify_person_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("verify_person_code")]
        public string verify_person_code { get; set; }
        /// <summary>
        /// verify_person_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("verify_person_name")]
        public string verify_person_name { get; set; }
        /// <summary>
        /// last_operator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_operator_key")]
        public string last_operator_key { get; set; }
        /// <summary>
        /// last_operator_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_operator_code")]
        public string last_operator_code { get; set; }
        /// <summary>
        /// last_operator_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_operator_name")]
        public string last_operator_name { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.T_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.T_key = KeyValue;
                                            }
        #endregion
    }
}