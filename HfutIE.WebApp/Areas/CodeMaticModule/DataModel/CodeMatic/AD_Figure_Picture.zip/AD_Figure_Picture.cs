//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Figure_Picture
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.07.23 10:40</date>
    /// </author>
    /// </summary>
    [Description("AD_Figure_Picture")]
    [PrimaryKey("fp_key")]
    public class AD_Figure_Picture : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// fp_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("fp_key")]
        public string fp_key { get; set; }
        /// <summary>
        /// figure
        /// </summary>
        /// <returns></returns>
        [DisplayName("figure")]
        public int? figure { get; set; }
        /// <summary>
        /// figure_content
        /// </summary>
        /// <returns></returns>
        [DisplayName("figure_content")]
        public string figure_content { get; set; }
        /// <summary>
        /// picture
        /// </summary>
        /// <returns></returns>
        [DisplayName("picture")]
        public string picture { get; set; }
        /// <summary>
        /// picture_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("picture_name")]
        public string picture_name { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creator_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key_I")]
        public string creator_key_I { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_key_I")]
        public string last_modified_key_I { get; set; }
        /// <summary>
        /// remark
        /// </summary>
        /// <returns></returns>
        [DisplayName("remark")]
        public string remark { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.fp_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.fp_key = KeyValue;
                                            }
        #endregion
    }
}