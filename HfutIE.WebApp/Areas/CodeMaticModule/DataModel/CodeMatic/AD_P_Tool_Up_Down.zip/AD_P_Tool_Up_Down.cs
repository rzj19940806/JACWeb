//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_Tool_Up_Down
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.13 11:25</date>
    /// </author>
    /// </summary>
    [Description("AD_P_Tool_Up_Down")]
    [PrimaryKey("ud_key")]
    public class AD_P_Tool_Up_Down : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ud_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("ud_key")]
        public string ud_key { get; set; }
        /// <summary>
        /// t_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("t_key")]
        public string t_key { get; set; }
        /// <summary>
        /// up_d_tool_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_d_tool_code")]
        public string up_d_tool_code { get; set; }
        /// <summary>
        /// down_cause
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_cause")]
        public string down_cause { get; set; }
        /// <summary>
        /// is_norm
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_norm")]
        public Single? is_norm { get; set; }
        /// <summary>
        /// up_picture
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_picture")]
        public string up_picture { get; set; }
        /// <summary>
        /// down_picture
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_picture")]
        public string down_picture { get; set; }
        /// <summary>
        /// single_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("single_status")]
        public Single? single_status { get; set; }
        /// <summary>
        /// single_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("single_num")]
        public Single? single_num { get; set; }
        /// <summary>
        /// single_pred_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("single_pred_num")]
        public Single? single_pred_num { get; set; }
        /// <summary>
        /// down_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_time")]
        public DateTime? down_time { get; set; }
        /// <summary>
        /// up_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_time")]
        public DateTime? up_time { get; set; }
        /// <summary>
        /// up_man_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_man_key")]
        public string up_man_key { get; set; }
        /// <summary>
        /// up_man_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_man_code")]
        public string up_man_code { get; set; }
        /// <summary>
        /// up_man_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_man_name")]
        public string up_man_name { get; set; }
        /// <summary>
        /// down_man_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_man_key")]
        public string down_man_key { get; set; }
        /// <summary>
        /// down_man_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_man_code")]
        public string down_man_code { get; set; }
        /// <summary>
        /// down_man_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_man_name")]
        public string down_man_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.ud_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.ud_key = KeyValue;
                                            }
        #endregion
    }
}