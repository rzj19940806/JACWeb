//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// P_ANDON_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.30 10:18</date>
    /// </author>
    /// </summary>
    public class P_ANDON_INFORBll : RepositoryFactory<P_ANDON_INFOR>
    {
    }
}