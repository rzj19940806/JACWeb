//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2021
// Software Developers @ HfutIE 2021
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// _FactoryBaseInformation
    /// <author>
    ///		<name>she</name>
    ///		<date>2021.01.26 19:50</date>
    /// </author>
    /// </summary>
    [Description("_FactoryBaseInformation")]
    [PrimaryKey("FactoryID")]
    public class _FactoryBaseInformation : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// FactoryID
        /// </summary>
        /// <returns></returns>
        [DisplayName("FactoryID")]
        public string FactoryID { get; set; }
        /// <summary>
        /// FactoryCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("FactoryCode")]
        public string FactoryCode { get; set; }
        /// <summary>
        /// FactoryName
        /// </summary>
        /// <returns></returns>
        [DisplayName("FactoryName")]
        public string FactoryName { get; set; }
        /// <summary>
        /// FactoryDescription
        /// </summary>
        /// <returns></returns>
        [DisplayName("FactoryDescription")]
        public string FactoryDescription { get; set; }
        /// <summary>
        /// CompanyID
        /// </summary>
        /// <returns></returns>
        [DisplayName("CompanyID")]
        public string CompanyID { get; set; }
        /// <summary>
        /// IsAvailable
        /// </summary>
        /// <returns></returns>
        [DisplayName("IsAvailable")]
        public bool? IsAvailable { get; set; }
        /// <summary>
        /// SolversID
        /// </summary>
        /// <returns></returns>
        [DisplayName("SolversID")]
        public string SolversID { get; set; }
        /// <summary>
        /// CreateTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateTime")]
        public DateTime? CreateTime { get; set; }
        /// <summary>
        /// CreatorID
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreatorID")]
        public string CreatorID { get; set; }
        /// <summary>
        /// LastModifiedTime
        /// </summary>
        /// <returns></returns>
        [DisplayName("LastModifiedTime")]
        public DateTime? LastModifiedTime { get; set; }
        /// <summary>
        /// ModifierID
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifierID")]
        public string ModifierID { get; set; }
        /// <summary>
        /// Remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("Remarks")]
        public string Remarks { get; set; }
        /// <summary>
        /// Reserve1
        /// </summary>
        /// <returns></returns>
        [DisplayName("Reserve1")]
        public string Reserve1 { get; set; }
        /// <summary>
        /// Reserve2
        /// </summary>
        /// <returns></returns>
        [DisplayName("Reserve2")]
        public string Reserve2 { get; set; }
        /// <summary>
        /// Reserve3
        /// </summary>
        /// <returns></returns>
        [DisplayName("Reserve3")]
        public string Reserve3 { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.FactoryID = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.FactoryID = KeyValue;
                                            }
        #endregion
    }
}