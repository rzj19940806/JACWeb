//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// PRAT_PRODUCTIONLIST_LIST
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.02.27 14:54</date>
    /// </author>
    /// </summary>
    public class PRAT_PRODUCTIONLIST_LISTBll : RepositoryFactory<PRAT_PRODUCTIONLIST_LIST>
    {
    }
}