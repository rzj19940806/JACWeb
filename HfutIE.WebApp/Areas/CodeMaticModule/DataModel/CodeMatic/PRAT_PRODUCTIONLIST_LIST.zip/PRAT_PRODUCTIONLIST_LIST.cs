//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// PRAT_PRODUCTIONLIST_LIST
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.02.27 14:54</date>
    /// </author>
    /// </summary>
    [Description("PRAT_PRODUCTIONLIST_LIST")]
    [PrimaryKey("part_p_line_key")]
    public class PRAT_PRODUCTIONLIST_LIST : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// part_p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_p_line_key")]
        public string part_p_line_key { get; set; }
        /// <summary>
        /// P_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_line_key")]
        public string P_line_key { get; set; }
        /// <summary>
        /// P_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_line_code")]
        public string P_line_code { get; set; }
        /// <summary>
        /// P_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_line_name")]
        public string P_line_name { get; set; }
        /// <summary>
        /// CreateDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateDate")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// CreateUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserId")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// CreateUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserName")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// ModifyDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyDate")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// ModifyUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyUserId")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// ModifyUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyUserName")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.part_p_line_key = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.part_p_line_key = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}