//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// PRODUCT_PART
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.03.14 20:06</date>
    /// </author>
    /// </summary>
    public class PRODUCT_PARTBll : RepositoryFactory<PRODUCT_PART>
    {
    }
}