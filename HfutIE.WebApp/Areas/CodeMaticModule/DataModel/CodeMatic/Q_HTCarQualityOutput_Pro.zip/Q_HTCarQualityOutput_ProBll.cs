//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2022
// Software Developers @ HfutIE 2022
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// �庸Ϳװ�������������̱�
    /// <author>
    ///		<name>she</name>
    ///		<date>2022.04.25 09:55</date>
    /// </author>
    /// </summary>
    public class Q_HTCarQualityOutput_ProBll : RepositoryFactory<Q_HTCarQualityOutput_Pro>
    {
    }
}