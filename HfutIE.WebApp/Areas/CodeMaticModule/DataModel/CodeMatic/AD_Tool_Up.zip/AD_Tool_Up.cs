//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Tool_Up
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.01.31 09:25</date>
    /// </author>
    /// </summary>
    [Description("AD_Tool_Up")]
    [PrimaryKey("up_key")]
    public class AD_Tool_Up : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// up_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_key")]
        public string up_key { get; set; }
        /// <summary>
        /// tool_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("tool_key")]
        public string tool_key { get; set; }
        /// <summary>
        /// tool_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("tool_name")]
        public string tool_name { get; set; }
        /// <summary>
        /// tool_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("tool_code")]
        public string tool_code { get; set; }
        /// <summary>
        /// tool_cate
        /// </summary>
        /// <returns></returns>
        [DisplayName("tool_cate")]
        public string tool_cate { get; set; }
        /// <summary>
        /// DLife
        /// </summary>
        /// <returns></returns>
        [DisplayName("DLife")]
        public Single? DLife { get; set; }
        /// <summary>
        /// alarm
        /// </summary>
        /// <returns></returns>
        [DisplayName("alarm")]
        public Single? alarm { get; set; }
        /// <summary>
        /// apply_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("apply_code")]
        public string apply_code { get; set; }
        /// <summary>
        /// apply_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("apply_name")]
        public string apply_name { get; set; }
        /// <summary>
        /// up_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_time")]
        public DateTime? up_time { get; set; }
        /// <summary>
        /// up_man_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_man_key")]
        public string up_man_key { get; set; }
        /// <summary>
        /// up_man_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_man_code")]
        public string up_man_code { get; set; }
        /// <summary>
        /// up_man_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_man_name")]
        public string up_man_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.up_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.up_key = KeyValue;
                                            }
        #endregion
    }
}