//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2020
// Software Developers @ HfutIE 2020
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// ProductInfo
    /// <author>
    ///		<name>she</name>
    ///		<date>2020.12.30 14:07</date>
    /// </author>
    /// </summary>
    [Description("ProductInfo")]
    [PrimaryKey("ID")]
    public class ProductInfo : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("ID")]
        public string ID { get; set; }
        /// <summary>
        /// ProductCode
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductCode")]
        public string ProductCode { get; set; }
        /// <summary>
        /// OrderNo
        /// </summary>
        /// <returns></returns>
        [DisplayName("OrderNo")]
        public string OrderNo { get; set; }
        /// <summary>
        /// ProductName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductName")]
        public string ProductName { get; set; }
        /// <summary>
        /// ProductModel
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductModel")]
        public string ProductModel { get; set; }
        /// <summary>
        /// ModelName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModelName")]
        public string ModelName { get; set; }
        /// <summary>
        /// ProductDesc
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductDesc")]
        public string ProductDesc { get; set; }
        /// <summary>
        /// ProductType
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductType")]
        public string ProductType { get; set; }
        /// <summary>
        /// ProductPower
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductPower")]
        public decimal? ProductPower { get; set; }
        /// <summary>
        /// ProductSpeed
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductSpeed")]
        public decimal? ProductSpeed { get; set; }
        /// <summary>
        /// InStop
        /// </summary>
        /// <returns></returns>
        [DisplayName("InStop")]
        public string InStop { get; set; }
        /// <summary>
        /// ProductWeight
        /// </summary>
        /// <returns></returns>
        [DisplayName("ProductWeight")]
        public decimal? ProductWeight { get; set; }
        /// <summary>
        /// EmissionLevel
        /// </summary>
        /// <returns></returns>
        [DisplayName("EmissionLevel")]
        public string EmissionLevel { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.ID = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.ID = KeyValue;
                                            }
        #endregion
    }
}