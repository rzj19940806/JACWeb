//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2020
// Software Developers @ HfutIE 2020
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// ProductInfo
    /// <author>
    ///		<name>she</name>
    ///		<date>2020.12.30 14:07</date>
    /// </author>
    /// </summary>
    public class ProductInfoBll : RepositoryFactory<ProductInfo>
    {
    }
}