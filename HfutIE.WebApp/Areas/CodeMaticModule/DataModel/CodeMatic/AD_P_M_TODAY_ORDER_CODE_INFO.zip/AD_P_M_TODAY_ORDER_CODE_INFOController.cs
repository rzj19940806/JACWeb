using HfutIE.Business;
using HfutIE.Entity;
using HfutIE.Utilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HfutIE.WebApp.Areas.CommonModule.Controllers
{
    /// <summary>
    /// AD_P_M_TODAY_ORDER_CODE_INFO������
    /// </summary>
    public class AD_P_M_TODAY_ORDER_CODE_INFOController : PublicController<AD_P_M_TODAY_ORDER_CODE_INFO>
    {
    }
}