//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_P_M_TODAY_ORDER_CODE_INFO
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.24 17:03</date>
    /// </author>
    /// </summary>
    public class AD_P_M_TODAY_ORDER_CODE_INFOBll : RepositoryFactory<AD_P_M_TODAY_ORDER_CODE_INFO>
    {
    }
}