//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// WC_CONFIG
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.03.03 11:16</date>
    /// </author>
    /// </summary>
    public class WC_CONFIGBll : RepositoryFactory<WC_CONFIG>
    {
    }
}