//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_EQUIP_EMITEM
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.01 15:15</date>
    /// </author>
    /// </summary>
    [Description("AD_EQUIP_EMITEM")]
    [PrimaryKey("key")]
    public class AD_EQUIP_EMITEM : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// key
        /// </summary>
        /// <returns></returns>
        [DisplayName("key")]
        public string key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// em_item_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("em_item_key")]
        public string em_item_key { get; set; }
        /// <summary>
        /// em_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("em_time")]
        public DateTime? em_time { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.key = KeyValue;
                                            }
        #endregion
    }
}