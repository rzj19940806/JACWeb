//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// PART
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.06.05 16:35</date>
    /// </author>
    /// </summary>
    [Description("PART")]
    [PrimaryKey("part_number")]
    public class PART : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key")]
        public string part_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// part_revision
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_revision")]
        public string part_revision { get; set; }
        /// <summary>
        /// description
        /// </summary>
        /// <returns></returns>
        [DisplayName("description")]
        public string description { get; set; }
        /// <summary>
        /// category
        /// </summary>
        /// <returns></returns>
        [DisplayName("category")]
        public string category { get; set; }
        /// <summary>
        /// image_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("image_key")]
        public string image_key { get; set; }
        /// <summary>
        /// inst_list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("inst_list_key")]
        public string inst_list_key { get; set; }
        /// <summary>
        /// bom_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("bom_name")]
        public string bom_name { get; set; }
        /// <summary>
        /// bom_revision
        /// </summary>
        /// <returns></returns>
        [DisplayName("bom_revision")]
        public string bom_revision { get; set; }
        /// <summary>
        /// quantity
        /// </summary>
        /// <returns></returns>
        [DisplayName("quantity")]
        public int? quantity { get; set; }
        /// <summary>
        /// consumption_duration
        /// </summary>
        /// <returns></returns>
        [DisplayName("consumption_duration")]
        public int? consumption_duration { get; set; }
        /// <summary>
        /// consumption_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("consumption_type")]
        public string consumption_type { get; set; }
        /// <summary>
        /// bom_tracked_mode
        /// </summary>
        /// <returns></returns>
        [DisplayName("bom_tracked_mode")]
        public int? bom_tracked_mode { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creation_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_u")]
        public DateTime? creation_time_u { get; set; }
        /// <summary>
        /// creation_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_z")]
        public string creation_time_z { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// revived
        /// </summary>
        /// <returns></returns>
        [DisplayName("revived")]
        public int? revived { get; set; }
        /// <summary>
        /// uda_0
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_0")]
        public string uda_0 { get; set; }
        /// <summary>
        /// uda_1
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_1")]
        public string uda_1 { get; set; }
        /// <summary>
        /// uda_2
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_2")]
        public string uda_2 { get; set; }
        /// <summary>
        /// uda_3
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_3")]
        public string uda_3 { get; set; }
        /// <summary>
        /// uda_4
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_4")]
        public string uda_4 { get; set; }
        /// <summary>
        /// uda_5
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_5")]
        public string uda_5 { get; set; }
        /// <summary>
        /// uda_6
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_6")]
        public string uda_6 { get; set; }
        /// <summary>
        /// uda_7
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_7")]
        public string uda_7 { get; set; }
        /// <summary>
        /// uda_8
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_8")]
        public string uda_8 { get; set; }
        /// <summary>
        /// uda_9
        /// </summary>
        /// <returns></returns>
        [DisplayName("uda_9")]
        public string uda_9 { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// effectivity_start
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_start")]
        public DateTime? effectivity_start { get; set; }
        /// <summary>
        /// effectivity_start_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_start_u")]
        public DateTime? effectivity_start_u { get; set; }
        /// <summary>
        /// effectivity_start_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_start_z")]
        public string effectivity_start_z { get; set; }
        /// <summary>
        /// effectivity_end
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_end")]
        public DateTime? effectivity_end { get; set; }
        /// <summary>
        /// effectivity_end_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_end_u")]
        public DateTime? effectivity_end_u { get; set; }
        /// <summary>
        /// effectivity_end_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("effectivity_end_z")]
        public string effectivity_end_z { get; set; }
        /// <summary>
        /// bill_account_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("bill_account_key")]
        public string bill_account_key { get; set; }
        /// <summary>
        /// build_account_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("build_account_key")]
        public string build_account_key { get; set; }
        /// <summary>
        /// ship_account_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("ship_account_key")]
        public string ship_account_key { get; set; }
        /// <summary>
        /// user_account_0
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_account_0")]
        public string user_account_0 { get; set; }
        /// <summary>
        /// shelf_life
        /// </summary>
        /// <returns></returns>
        [DisplayName("shelf_life")]
        public int? shelf_life { get; set; }
        /// <summary>
        /// warranty_period
        /// </summary>
        /// <returns></returns>
        [DisplayName("warranty_period")]
        public int? warranty_period { get; set; }
        /// <summary>
        /// unit_of_measure
        /// </summary>
        /// <returns></returns>
        [DisplayName("unit_of_measure")]
        public string unit_of_measure { get; set; }
        /// <summary>
        /// standard_cost
        /// </summary>
        /// <returns></returns>
        [DisplayName("standard_cost")]
        public Single? standard_cost { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// update_privilege_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("update_privilege_key")]
        public string update_privilege_key { get; set; }
        /// <summary>
        /// delete_privilege_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("delete_privilege_key")]
        public string delete_privilege_key { get; set; }
        /// <summary>
        /// part_ext_revision
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_ext_revision")]
        public string part_ext_revision { get; set; }
        /// <summary>
        /// replacement_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("replacement_type")]
        public string replacement_type { get; set; }
        /// <summary>
        /// mixing_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("mixing_type")]
        public int? mixing_type { get; set; }
        /// <summary>
        /// carrier_class_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("carrier_class_key")]
        public string carrier_class_key { get; set; }
        /// <summary>
        /// storage_class_enforced
        /// </summary>
        /// <returns></returns>
        [DisplayName("storage_class_enforced")]
        public int? storage_class_enforced { get; set; }
        /// <summary>
        /// logically_empty_quantity
        /// </summary>
        /// <returns></returns>
        [DisplayName("logically_empty_quantity")]
        public string logically_empty_quantity { get; set; }
        /// <summary>
        /// storage_unit_class_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("storage_unit_class_key")]
        public string storage_unit_class_key { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.part_number = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.part_number = KeyValue;
                                            }
        #endregion
    }
}