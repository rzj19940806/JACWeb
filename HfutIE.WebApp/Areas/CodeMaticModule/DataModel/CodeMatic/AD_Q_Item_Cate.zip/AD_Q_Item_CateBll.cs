//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_Q_Item_Cate
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.09.02 14:54</date>
    /// </author>
    /// </summary>
    public class AD_Q_Item_CateBll : RepositoryFactory<AD_Q_Item_Cate>
    {
    }
}