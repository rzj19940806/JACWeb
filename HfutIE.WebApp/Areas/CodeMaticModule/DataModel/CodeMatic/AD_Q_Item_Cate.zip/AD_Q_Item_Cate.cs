//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Q_Item_Cate
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.09.02 14:54</date>
    /// </author>
    /// </summary>
    [Description("AD_Q_Item_Cate")]
    [PrimaryKey("q_item_cate_key")]
    public class AD_Q_Item_Cate : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// q_item_cate_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("q_item_cate_key")]
        public string q_item_cate_key { get; set; }
        /// <summary>
        /// qua_item_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("qua_item_key")]
        public string qua_item_key { get; set; }
        /// <summary>
        /// q_item_cate_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("q_item_cate_code")]
        public string q_item_cate_code { get; set; }
        /// <summary>
        /// q_item_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("q_item_name")]
        public string q_item_name { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.q_item_cate_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.q_item_cate_key = KeyValue;
                                            }
        #endregion
    }
}