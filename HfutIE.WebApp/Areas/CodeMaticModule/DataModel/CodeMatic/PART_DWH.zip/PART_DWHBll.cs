//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// PART_DWH
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.03.09 20:31</date>
    /// </author>
    /// </summary>
    public class PART_DWHBll : RepositoryFactory<PART_DWH>
    {
    }
}