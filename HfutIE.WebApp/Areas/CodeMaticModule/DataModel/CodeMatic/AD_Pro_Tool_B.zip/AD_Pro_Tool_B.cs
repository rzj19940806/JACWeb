//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Pro_Tool_B
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.11 18:59</date>
    /// </author>
    /// </summary>
    [Description("AD_Pro_Tool_B")]
    [PrimaryKey("pro_tool_key")]
    public class AD_Pro_Tool_B : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// pro_tool_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_tool_key")]
        public string pro_tool_key { get; set; }
        /// <summary>
        /// plat_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("plat_key")]
        public string plat_key { get; set; }
        /// <summary>
        /// part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key")]
        public string part_key { get; set; }
        /// <summary>
        /// pro_tool_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_tool_code")]
        public string pro_tool_code { get; set; }
        /// <summary>
        /// pro_tool_cate
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_tool_cate")]
        public string pro_tool_cate { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.pro_tool_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.pro_tool_key = KeyValue;
                                            }
        #endregion
    }
}