//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Tool_Hilt_B
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.01.11 11:19</date>
    /// </author>
    /// </summary>
    [Description("AD_Tool_Hilt_B")]
    [PrimaryKey("hilt_key")]
    public class AD_Tool_Hilt_B : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// hilt_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("hilt_key")]
        public string hilt_key { get; set; }
        /// <summary>
        /// hilt_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("hilt_name")]
        public string hilt_name { get; set; }
        /// <summary>
        /// stan_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("stan_code")]
        public string stan_code { get; set; }
        /// <summary>
        /// picture
        /// </summary>
        /// <returns></returns>
        [DisplayName("picture")]
        public string picture { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.hilt_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.hilt_key = KeyValue;
                                            }
        #endregion
    }
}