//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_PASS_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.07.17 15:14</date>
    /// </author>
    /// </summary>
    [Description("AD_P_PASS_INFOR")]
    [PrimaryKey("atr_key")]
    public class AD_P_PASS_INFOR : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// atr_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("atr_key")]
        public string atr_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// atr_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("atr_name")]
        public string atr_name { get; set; }
        /// <summary>
        /// purge_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("purge_status")]
        public int? purge_status { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creation_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_u")]
        public DateTime? creation_time_u { get; set; }
        /// <summary>
        /// creation_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_z")]
        public string creation_time_z { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// parent_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("parent_key")]
        public string parent_key { get; set; }
        /// <summary>
        /// addr_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_key_I")]
        public string addr_key_I { get; set; }
        /// <summary>
        /// addr_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_name_S")]
        public string addr_name_S { get; set; }
        /// <summary>
        /// addr_path_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_path_S")]
        public string addr_path_S { get; set; }
        /// <summary>
        /// area_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code_S")]
        public string area_code_S { get; set; }
        /// <summary>
        /// area_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key_I")]
        public string area_key_I { get; set; }
        /// <summary>
        /// area_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name_S")]
        public string area_name_S { get; set; }
        /// <summary>
        /// continued_time_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("continued_time_I")]
        public string continued_time_I { get; set; }
        /// <summary>
        /// end_time_T
        /// </summary>
        /// <returns></returns>
        [DisplayName("end_time_T")]
        public DateTime? end_time_T { get; set; }
        /// <summary>
        /// end_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("end_time_u")]
        public DateTime? end_time_u { get; set; }
        /// <summary>
        /// end_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("end_time_z")]
        public string end_time_z { get; set; }
        /// <summary>
        /// equip_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_code_S")]
        public string equip_code_S { get; set; }
        /// <summary>
        /// equip_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key_I")]
        public string equip_key_I { get; set; }
        /// <summary>
        /// equip_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_name_S")]
        public string equip_name_S { get; set; }
        /// <summary>
        /// equip_state_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_state_S")]
        public string equip_state_S { get; set; }
        /// <summary>
        /// order_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("order_code_S")]
        public string order_code_S { get; set; }
        /// <summary>
        /// p_line_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code_S")]
        public string p_line_code_S { get; set; }
        /// <summary>
        /// p_line_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key_I")]
        public string p_line_key_I { get; set; }
        /// <summary>
        /// p_line_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name_S")]
        public string p_line_name_S { get; set; }
        /// <summary>
        /// site_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_key_I")]
        public string site_key_I { get; set; }
        /// <summary>
        /// site_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_code_S")]
        public string site_code_S { get; set; }
        /// <summary>
        /// site_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_name_S")]
        public string site_name_S { get; set; }
        /// <summary>
        /// start_time_T
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time_T")]
        public DateTime? start_time_T { get; set; }
        /// <summary>
        /// start_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time_u")]
        public DateTime? start_time_u { get; set; }
        /// <summary>
        /// start_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time_z")]
        public string start_time_z { get; set; }
        /// <summary>
        /// user_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_code_S")]
        public string user_code_S { get; set; }
        /// <summary>
        /// user_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_key_I")]
        public string user_key_I { get; set; }
        /// <summary>
        /// user_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_name_S")]
        public string user_name_S { get; set; }
        /// <summary>
        /// wc_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code_S")]
        public string wc_code_S { get; set; }
        /// <summary>
        /// wc_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key_I")]
        public string wc_key_I { get; set; }
        /// <summary>
        /// wc_name_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name_S")]
        public string wc_name_S { get; set; }
        /// <summary>
        /// wo_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("wo_code_S")]
        public string wo_code_S { get; set; }
        /// <summary>
        /// woi_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("woi_code_S")]
        public string woi_code_S { get; set; }
        /// <summary>
        /// order_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("order_code")]
        public string order_code { get; set; }
        /// <summary>
        /// pro_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_born_code")]
        public string pro_born_code { get; set; }
        /// <summary>
        /// pro_ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_ID")]
        public string pro_ID { get; set; }
        /// <summary>
        /// pro_modle_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_modle_no")]
        public string pro_modle_no { get; set; }
        /// <summary>
        /// pro_isOK
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_isOK")]
        public string pro_isOK { get; set; }
        /// <summary>
        /// pro_isSpecial
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_isSpecial")]
        public string pro_isSpecial { get; set; }
        /// <summary>
        /// platform_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("platform_no")]
        public string platform_no { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.atr_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.atr_key = KeyValue;
                                            }
        #endregion
    }
}