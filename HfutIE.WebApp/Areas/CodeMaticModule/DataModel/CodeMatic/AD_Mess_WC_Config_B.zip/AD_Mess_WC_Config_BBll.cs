//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_Mess_WC_Config_B
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.07 10:35</date>
    /// </author>
    /// </summary>
    public class AD_Mess_WC_Config_BBll : RepositoryFactory<AD_Mess_WC_Config_B>
    {
    }
}