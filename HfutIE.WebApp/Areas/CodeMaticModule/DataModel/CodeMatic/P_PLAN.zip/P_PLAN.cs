//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// P_PLAN
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.05 15:58</date>
    /// </author>
    /// </summary>
    [Description("P_PLAN")]
    [PrimaryKey("mes_plan_key")]
    public class P_PLAN : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// mes_plan_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("mes_plan_key")]
        public string mes_plan_key { get; set; }
        /// <summary>
        /// mes_plan_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("mes_plan_code")]
        public string mes_plan_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// execution_queue_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("execution_queue_no")]
        public int? execution_queue_no { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// plan_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_num")]
        public int? plan_num { get; set; }
        /// <summary>
        /// plan_date
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_date")]
        public DateTime? plan_date { get; set; }
        /// <summary>
        /// plan_start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_start_time")]
        public DateTime? plan_start_time { get; set; }
        /// <summary>
        /// plan_ending_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_ending_time")]
        public DateTime? plan_ending_time { get; set; }
        /// <summary>
        /// actual_start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("actual_start_time")]
        public DateTime? actual_start_time { get; set; }
        /// <summary>
        /// actual_ending_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("actual_ending_time")]
        public DateTime? actual_ending_time { get; set; }
        /// <summary>
        /// online_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("online_num")]
        public int? online_num { get; set; }
        /// <summary>
        /// offline_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("offline_num")]
        public int? offline_num { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        /// <summary>
        /// distribution_workshop
        /// </summary>
        /// <returns></returns>
        [DisplayName("distribution_workshop")]
        public string distribution_workshop { get; set; }
        /// <summary>
        /// reference_vehicle
        /// </summary>
        /// <returns></returns>
        [DisplayName("reference_vehicle")]
        public string reference_vehicle { get; set; }
        /// <summary>
        /// plan_source
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_source")]
        public string plan_source { get; set; }
        /// <summary>
        /// exception_flag
        /// </summary>
        /// <returns></returns>
        [DisplayName("exception_flag")]
        public string exception_flag { get; set; }
        /// <summary>
        /// execution_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("execution_status")]
        public string execution_status { get; set; }
        /// <summary>
        /// complete_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("complete_status")]
        public string complete_status { get; set; }
        /// <summary>
        /// last_update_date
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_update_date")]
        public DateTime? last_update_date { get; set; }
        /// <summary>
        /// brake_drums_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("brake_drums_code")]
        public string brake_drums_code { get; set; }
        /// <summary>
        /// front_axle_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("front_axle_code")]
        public string front_axle_code { get; set; }
        /// <summary>
        /// brake_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("brake_code")]
        public string brake_code { get; set; }
        /// <summary>
        /// straight_bar_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("straight_bar_code")]
        public string straight_bar_code { get; set; }
        /// <summary>
        /// reserve1
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve1")]
        public string reserve1 { get; set; }
        /// <summary>
        /// reserve2
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve2")]
        public string reserve2 { get; set; }
        /// <summary>
        /// reserve3
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve3")]
        public string reserve3 { get; set; }
        /// <summary>
        /// reserve4
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve4")]
        public string reserve4 { get; set; }
        /// <summary>
        /// reserve5
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve5")]
        public string reserve5 { get; set; }
        /// <summary>
        /// reserve6
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve6")]
        public string reserve6 { get; set; }
        /// <summary>
        /// reserve7
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve7")]
        public string reserve7 { get; set; }
        /// <summary>
        /// reserve8
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve8")]
        public string reserve8 { get; set; }
        /// <summary>
        /// reserve9
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve9")]
        public string reserve9 { get; set; }
        /// <summary>
        /// reserve10
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve10")]
        public string reserve10 { get; set; }
        /// <summary>
        /// CreateDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateDate")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// CreateUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserId")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// CreateUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserName")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// ModifyDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyDate")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// ModifyUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyUserId")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// ModifyUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyUserName")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.mes_plan_key = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.mes_plan_key = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}