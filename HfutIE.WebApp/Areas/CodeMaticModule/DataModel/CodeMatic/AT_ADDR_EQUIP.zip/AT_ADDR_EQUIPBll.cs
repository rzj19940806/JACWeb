//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AT_ADDR_EQUIP
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.10.20 10:59</date>
    /// </author>
    /// </summary>
    public class AT_ADDR_EQUIPBll : RepositoryFactory<AT_ADDR_EQUIP>
    {
    }
}