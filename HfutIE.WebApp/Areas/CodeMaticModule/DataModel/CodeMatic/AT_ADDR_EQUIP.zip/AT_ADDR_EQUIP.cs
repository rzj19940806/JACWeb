//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AT_ADDR_EQUIP
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.10.20 10:59</date>
    /// </author>
    /// </summary>
    [Description("AT_ADDR_EQUIP")]
    [PrimaryKey("atr_key")]
    public class AT_ADDR_EQUIP : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// atr_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("atr_key")]
        public string atr_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// atr_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("atr_name")]
        public string atr_name { get; set; }
        /// <summary>
        /// purge_status
        /// </summary>
        /// <returns></returns>
        [DisplayName("purge_status")]
        public int? purge_status { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creation_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_u")]
        public DateTime? creation_time_u { get; set; }
        /// <summary>
        /// creation_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_z")]
        public string creation_time_z { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// parent_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("parent_key")]
        public string parent_key { get; set; }
        /// <summary>
        /// addr_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("addr_key_I")]
        public string addr_key_I { get; set; }
        /// <summary>
        /// alarm_code_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("alarm_code_S")]
        public string alarm_code_S { get; set; }
        /// <summary>
        /// alarm_description_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("alarm_description_S")]
        public string alarm_description_S { get; set; }
        /// <summary>
        /// alarm_grade_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("alarm_grade_S")]
        public string alarm_grade_S { get; set; }
        /// <summary>
        /// creator_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key_I")]
        public string creator_key_I { get; set; }
        /// <summary>
        /// equip_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key_I")]
        public string equip_key_I { get; set; }
        /// <summary>
        /// last_modifier_key_I
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key_I")]
        public string last_modifier_key_I { get; set; }
        /// <summary>
        /// remarks_S
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks_S")]
        public string remarks_S { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.atr_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.atr_key = KeyValue;
                                            }
        #endregion
    }
}