//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// P_MACHINE_PRODUCT_STATE
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.26 11:34</date>
    /// </author>
    /// </summary>
    [Description("P_MACHINE_PRODUCT_STATE")]
    [PrimaryKey("p_machine_p_s_key")]
    public class P_MACHINE_PRODUCT_STATE : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string p_machine_p_s_key { get; set; }
        /// <summary>
        /// account_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("account_code")]
        public string account_code { get; set; }
        /// <summary>
        /// account_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("account_name")]
        public string account_name { get; set; }
        /// <summary>
        /// site_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_key")]
        public string site_key { get; set; }
        /// <summary>
        /// site_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_code")]
        public string site_code { get; set; }
        /// <summary>
        /// site_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_name")]
        public string site_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// ws_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("ws_key")]
        public string ws_key { get; set; }
        /// <summary>
        /// ws_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("ws_code")]
        public string ws_code { get; set; }
        /// <summary>
        /// ws_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("ws_name")]
        public string ws_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// �����߱��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����߱��")]
        public string p_line_code { get; set; }
        /// <summary>
        /// ����������
        /// </summary>
        /// <returns></returns>
        [DisplayName("����������")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// equip_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_code")]
        public string equip_code { get; set; }
        /// <summary>
        /// equip_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_name")]
        public string equip_name { get; set; }
        /// <summary>
        /// shift_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("shift_key")]
        public string shift_key { get; set; }
        /// <summary>
        /// shift_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("shift_code")]
        public string shift_code { get; set; }
        /// <summary>
        /// shift_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("shift_name")]
        public string shift_name { get; set; }
        /// <summary>
        /// team_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("team_key")]
        public string team_key { get; set; }
        /// <summary>
        /// team_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("team_code")]
        public string team_code { get; set; }
        /// <summary>
        /// team_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("team_name")]
        public string team_name { get; set; }
        /// <summary>
        /// staff_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("staff_key")]
        public string staff_key { get; set; }
        /// <summary>
        /// staff_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("staff_code")]
        public string staff_code { get; set; }
        /// <summary>
        /// staff_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("staff_name")]
        public string staff_name { get; set; }
        /// <summary>
        /// mes_plan_m_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("mes_plan_m_key")]
        public string mes_plan_m_key { get; set; }
        /// <summary>
        /// mes_plan_m_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("mes_plan_m_code")]
        public string mes_plan_m_code { get; set; }
        /// <summary>
        /// plan_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_num")]
        public string plan_num { get; set; }
        /// <summary>
        /// plan_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_no")]
        public string plan_no { get; set; }
        /// <summary>
        /// bom_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("bom_key")]
        public string bom_key { get; set; }
        /// <summary>
        /// product_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_key")]
        public string product_key { get; set; }
        /// <summary>
        /// ��Ʒ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒ���")]
        public string product_code { get; set; }
        /// <summary>
        /// ��Ʒ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒ����")]
        public string product_name { get; set; }
        /// <summary>
        /// ��Ʒ������
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒ������")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_batch_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_batch_no")]
        public string product_batch_no { get; set; }
        /// <summary>
        /// ��Ʒ����֤
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒ����֤")]
        public string product_born_code { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// ��Ʒϵ�к�
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒϵ�к�")]
        public string product_serial_no { get; set; }
        /// <summary>
        /// ��Ʒ�ṹ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒ�ṹ��")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// ��Ʒ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ʒ����")]
        public string product_type { get; set; }
        /// <summary>
        /// is_OK
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_OK")]
        public string is_OK { get; set; }
        /// <summary>
        /// operated_state
        /// </summary>
        /// <returns></returns>
        [DisplayName("operated_state")]
        public string operated_state { get; set; }
        /// <summary>
        /// ��������ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������ʱ��")]
        public DateTime? machine_online_time { get; set; }
        /// <summary>
        /// ��������ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��������ʱ��")]
        public DateTime? machine_offline_time { get; set; }
        /// <summary>
        /// storage_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("storage_time")]
        public DateTime? storage_time { get; set; }
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string remarks { get; set; }
        /// <summary>
        /// reserve01
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve01")]
        public string reserve01 { get; set; }
        /// <summary>
        /// reserve02
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve02")]
        public string reserve02 { get; set; }
        /// <summary>
        /// reserve03
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve03")]
        public string reserve03 { get; set; }
        /// <summary>
        /// reserve04
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve04")]
        public string reserve04 { get; set; }
        /// <summary>
        /// reserve05
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve05")]
        public string reserve05 { get; set; }
        /// <summary>
        /// reserve06
        /// </summary>
        /// <returns></returns>
        [DisplayName("reserve06")]
        public string reserve06 { get; set; }
        /// <summary>
        /// CreateDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateDate")]
        public DateTime? CreateDate { get; set; }
        /// <summary>
        /// CreateUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserId")]
        public string CreateUserId { get; set; }
        /// <summary>
        /// CreateUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("CreateUserName")]
        public string CreateUserName { get; set; }
        /// <summary>
        /// ModifyDate
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyDate")]
        public DateTime? ModifyDate { get; set; }
        /// <summary>
        /// ModifyUserId
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyUserId")]
        public string ModifyUserId { get; set; }
        /// <summary>
        /// ModifyUserName
        /// </summary>
        /// <returns></returns>
        [DisplayName("ModifyUserName")]
        public string ModifyUserName { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.p_machine_p_s_key = CommonHelper.GetGuid;
            this.CreateDate = DateTime.Now;
            this.CreateUserId = ManageProvider.Provider.Current().UserId;
            this.CreateUserName = ManageProvider.Provider.Current().UserName;
        }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.p_machine_p_s_key = KeyValue;
            this.ModifyDate = DateTime.Now;
            this.ModifyUserId = ManageProvider.Provider.Current().UserId;
            this.ModifyUserName = ManageProvider.Provider.Current().UserName;
        }
        #endregion
    }
}