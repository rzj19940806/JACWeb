//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Fault_task_quality
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.13 19:54</date>
    /// </author>
    /// </summary>
    [Description("AD_Fault_task_quality")]
    [PrimaryKey("F_t_q_key")]
    public class AD_Fault_task_quality : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// F_t_q_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("F_t_q_key")]
        public string F_t_q_key { get; set; }
        /// <summary>
        /// Fault_task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("Fault_task_key")]
        public string Fault_task_key { get; set; }
        /// <summary>
        /// P_Fault_task_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_Fault_task_code")]
        public string P_Fault_task_code { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// item_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("item_name")]
        public string item_name { get; set; }
        /// <summary>
        /// item_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("item_type")]
        public string item_type { get; set; }
        /// <summary>
        /// item_unit
        /// </summary>
        /// <returns></returns>
        [DisplayName("item_unit")]
        public string item_unit { get; set; }
        /// <summary>
        /// up_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("up_value")]
        public string up_value { get; set; }
        /// <summary>
        /// down_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("down_value")]
        public string down_value { get; set; }
        /// <summary>
        /// goal_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("goal_value")]
        public string goal_value { get; set; }
        /// <summary>
        /// actual_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("actual_value")]
        public string actual_value { get; set; }
        /// <summary>
        /// result
        /// </summary>
        /// <returns></returns>
        [DisplayName("result")]
        public string result { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// product_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name")]
        public string product_name { get; set; }
        /// <summary>
        /// product_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type")]
        public string product_type { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// product_struct_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// product_abb
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_born_code")]
        public string product_born_code { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// eqm_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_key")]
        public string eqm_key { get; set; }
        /// <summary>
        /// eqm_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_code")]
        public string eqm_code { get; set; }
        /// <summary>
        /// eqm_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("eqm_name")]
        public string eqm_name { get; set; }
        /// <summary>
        /// OK_NG
        /// </summary>
        /// <returns></returns>
        [DisplayName("OK_NG")]
        public string OK_NG { get; set; }
        /// <summary>
        /// input_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("input_time")]
        public DateTime? input_time { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.F_t_q_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.F_t_q_key = KeyValue;
                                            }
        #endregion
    }
}