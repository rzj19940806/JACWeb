//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2021
// Software Developers @ HfutIE 2021
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// BBdbR_AVIAcitonConfig
    /// <author>
    ///		<name>she</name>
    ///		<date>2021.09.09 21:47</date>
    /// </author>
    /// </summary>
    public class BBdbR_AVIAcitonConfigBll : RepositoryFactory<BBdbR_AVIAcitonConfig>
    {
    }
}