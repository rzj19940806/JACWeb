//=====================================================================================
// All Rights Reserved , Copyright @ Learun 2016
// Software Developers @ Learun 2016
//=====================================================================================

using LeaRun.Entity;
using LeaRun.Repository;
using LeaRun.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace LeaRun.Business
{
    /// <summary>
    /// Base_Factory
    /// <author>
    ///		<name>she</name>
    ///		<date>2016.10.04 15:06</date>
    /// </author>
    /// </summary>
    public class Base_FactoryBll : RepositoryFactory<Base_Factory>
    {
    }
}