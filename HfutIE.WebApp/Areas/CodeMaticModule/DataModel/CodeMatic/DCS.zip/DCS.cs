//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// DCS
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.26 12:11</date>
    /// </author>
    /// </summary>
    [Description("DCS")]
    [PrimaryKey("dcs_name")]
    public class DCS : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// dcs_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("dcs_key")]
        public string dcs_key { get; set; }
        /// <summary>
        /// site_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_num")]
        public int? site_num { get; set; }
        /// <summary>
        /// dcs_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("dcs_name")]
        public string dcs_name { get; set; }
        /// <summary>
        /// description
        /// </summary>
        /// <returns></returns>
        [DisplayName("description")]
        public string description { get; set; }
        /// <summary>
        /// category
        /// </summary>
        /// <returns></returns>
        [DisplayName("category")]
        public string category { get; set; }
        /// <summary>
        /// image_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("image_key")]
        public string image_key { get; set; }
        /// <summary>
        /// author
        /// </summary>
        /// <returns></returns>
        [DisplayName("author")]
        public string author { get; set; }
        /// <summary>
        /// collection_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("collection_level")]
        public int? collection_level { get; set; }
        /// <summary>
        /// inst_list_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("inst_list_key")]
        public string inst_list_key { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creation_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time")]
        public DateTime? creation_time { get; set; }
        /// <summary>
        /// creation_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_u")]
        public DateTime? creation_time_u { get; set; }
        /// <summary>
        /// creation_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("creation_time_z")]
        public string creation_time_z { get; set; }
        /// <summary>
        /// last_modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modifier_key")]
        public string last_modifier_key { get; set; }
        /// <summary>
        /// last_modified_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time")]
        public DateTime? last_modified_time { get; set; }
        /// <summary>
        /// last_modified_time_u
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_u")]
        public DateTime? last_modified_time_u { get; set; }
        /// <summary>
        /// last_modified_time_z
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_modified_time_z")]
        public string last_modified_time_z { get; set; }
        /// <summary>
        /// version
        /// </summary>
        /// <returns></returns>
        [DisplayName("version")]
        public int? version { get; set; }
        /// <summary>
        /// access_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_level")]
        public int? access_level { get; set; }
        /// <summary>
        /// checkout_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("checkout_user_key")]
        public string checkout_user_key { get; set; }
        /// <summary>
        /// xfr_insert_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_insert_pid")]
        public int? xfr_insert_pid { get; set; }
        /// <summary>
        /// xfr_update_pid
        /// </summary>
        /// <returns></returns>
        [DisplayName("xfr_update_pid")]
        public int? xfr_update_pid { get; set; }
        /// <summary>
        /// static_data
        /// </summary>
        /// <returns></returns>
        [DisplayName("static_data")]
        public int? static_data { get; set; }
        /// <summary>
        /// rt_dcs_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("rt_dcs_name")]
        public string rt_dcs_name { get; set; }
        /// <summary>
        /// trx_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("trx_id")]
        public string trx_id { get; set; }
        /// <summary>
        /// update_privilege_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("update_privilege_key")]
        public string update_privilege_key { get; set; }
        /// <summary>
        /// delete_privilege_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("delete_privilege_key")]
        public string delete_privilege_key { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.dcs_name = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.dcs_name = KeyValue;
                                            }
        #endregion
    }
}