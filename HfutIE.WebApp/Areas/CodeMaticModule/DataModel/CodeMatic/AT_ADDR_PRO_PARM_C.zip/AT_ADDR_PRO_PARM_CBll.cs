//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AT_ADDR_PRO_PARM_C
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.21 14:20</date>
    /// </author>
    /// </summary>
    public class AT_ADDR_PRO_PARM_CBll : RepositoryFactory<AT_ADDR_PRO_PARM_C>
    {
    }
}