//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_DOC_Product_Solve_Tasks
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.11 09:50</date>
    /// </author>
    /// </summary>
    [Description("AD_DOC_Product_Solve_Tasks")]
    [PrimaryKey("solve_tasks_key")]
    public class AD_DOC_Product_Solve_Tasks : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// solve_tasks_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("solve_tasks_key")]
        public string solve_tasks_key { get; set; }
        /// <summary>
        /// solve_task_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("solve_task_code")]
        public string solve_task_code { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// wo_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wo_code")]
        public string wo_code { get; set; }
        /// <summary>
        /// woi_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("woi_code")]
        public string woi_code { get; set; }
        /// <summary>
        /// order_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("order_code")]
        public string order_code { get; set; }
        /// <summary>
        /// plan_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_num")]
        public string plan_num { get; set; }
        /// <summary>
        /// lot_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_name")]
        public string lot_name { get; set; }
        /// <summary>
        /// product_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_key")]
        public string product_key { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// product_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name")]
        public string product_name { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// product_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type")]
        public string product_type { get; set; }
        /// <summary>
        /// product_struct_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// product_abb
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_born_code")]
        public string product_born_code { get; set; }
        /// <summary>
        /// plan_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_no")]
        public string plan_no { get; set; }
        /// <summary>
        /// site_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_key")]
        public string site_key { get; set; }
        /// <summary>
        /// site_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_code")]
        public string site_code { get; set; }
        /// <summary>
        /// site_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_name")]
        public string site_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_key")]
        public string user_key { get; set; }
        /// <summary>
        /// user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_code")]
        public string user_code { get; set; }
        /// <summary>
        /// user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_name")]
        public string user_name { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// equip_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_code")]
        public string equip_code { get; set; }
        /// <summary>
        /// equip_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_name")]
        public string equip_name { get; set; }
        /// <summary>
        /// imagepath
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagepath")]
        public string imagepath { get; set; }
        /// <summary>
        /// imagefile
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagefile")]
        public string imagefile { get; set; }
        /// <summary>
        /// fault_description
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_description")]
        public string fault_description { get; set; }
        /// <summary>
        /// solve_content
        /// </summary>
        /// <returns></returns>
        [DisplayName("solve_content")]
        public string solve_content { get; set; }
        /// <summary>
        /// ps_category
        /// </summary>
        /// <returns></returns>
        [DisplayName("ps_category")]
        public string ps_category { get; set; }
        /// <summary>
        /// mt_recorder_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("mt_recorder_key")]
        public string mt_recorder_key { get; set; }
        /// <summary>
        /// mt_recorder_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("mt_recorder_code")]
        public string mt_recorder_code { get; set; }
        /// <summary>
        /// mt_recorder_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("mt_recorder_name")]
        public string mt_recorder_name { get; set; }
        /// <summary>
        /// check_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_user_key")]
        public string check_user_key { get; set; }
        /// <summary>
        /// check_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_user_code")]
        public string check_user_code { get; set; }
        /// <summary>
        /// check_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_user_name")]
        public string check_user_name { get; set; }
        /// <summary>
        /// check_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_time")]
        public DateTime? check_time { get; set; }
        /// <summary>
        /// starter_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("starter_key")]
        public string starter_key { get; set; }
        /// <summary>
        /// starter_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("starter_code")]
        public string starter_code { get; set; }
        /// <summary>
        /// starter_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("starter_name")]
        public string starter_name { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creator_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_code")]
        public string creator_code { get; set; }
        /// <summary>
        /// creator_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_name")]
        public string creator_name { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// modifier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_code")]
        public string modifier_code { get; set; }
        /// <summary>
        /// modifier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_name")]
        public string modifier_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.solve_tasks_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.solve_tasks_key = KeyValue;
                                            }
        #endregion
    }
}