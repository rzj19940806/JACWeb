//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// MATERIAL_STORAGE_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.31 09:58</date>
    /// </author>
    /// </summary>
    public class MATERIAL_STORAGE_INFORBll : RepositoryFactory<MATERIAL_STORAGE_INFOR>
    {
    }
}