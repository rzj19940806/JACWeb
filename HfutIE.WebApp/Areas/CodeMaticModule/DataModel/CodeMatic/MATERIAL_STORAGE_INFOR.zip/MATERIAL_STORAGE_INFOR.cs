//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// MATERIAL_STORAGE_INFOR
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.05.31 09:58</date>
    /// </author>
    /// </summary>
    [Description("MATERIAL_STORAGE_INFOR")]
    [PrimaryKey("material_storage_key")]
    public class MATERIAL_STORAGE_INFOR : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// material_storage_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("material_storage_key")]
        public string material_storage_key { get; set; }
        /// <summary>
        /// daliy_warehouse_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("daliy_warehouse_key")]
        public string daliy_warehouse_key { get; set; }
        /// <summary>
        /// part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key")]
        public string part_key { get; set; }
        /// <summary>
        /// part_batch_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_batch_no")]
        public string part_batch_no { get; set; }
        /// <summary>
        /// part_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_code")]
        public string part_code { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// supplier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_key")]
        public string supplier_key { get; set; }
        /// <summary>
        /// supplier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_code")]
        public string supplier_code { get; set; }
        /// <summary>
        /// supplier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_name")]
        public string supplier_name { get; set; }
        /// <summary>
        /// num
        /// </summary>
        /// <returns></returns>
        [DisplayName("num")]
        public int? num { get; set; }
        /// <summary>
        /// incoming_date
        /// </summary>
        /// <returns></returns>
        [DisplayName("incoming_date")]
        public DateTime? incoming_date { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.material_storage_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.material_storage_key = KeyValue;
                                            }
        #endregion
    }
}