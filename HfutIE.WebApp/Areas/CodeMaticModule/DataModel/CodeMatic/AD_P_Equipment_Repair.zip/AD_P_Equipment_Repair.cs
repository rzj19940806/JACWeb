//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_Equipment_Repair
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.03.06 18:12</date>
    /// </author>
    /// </summary>
    [Description("AD_P_Equipment_Repair")]
    [PrimaryKey("p_er_key")]
    public class AD_P_Equipment_Repair : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// p_er_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_er_key")]
        public string p_er_key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// equip_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_code")]
        public string equip_code { get; set; }
        /// <summary>
        /// equip_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_name")]
        public string equip_name { get; set; }
        /// <summary>
        /// equip_model
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_model")]
        public string equip_model { get; set; }
        /// <summary>
        /// equip_useDept
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_useDept")]
        public string equip_useDept { get; set; }
        /// <summary>
        /// urgency_degree
        /// </summary>
        /// <returns></returns>
        [DisplayName("urgency_degree")]
        public string urgency_degree { get; set; }
        /// <summary>
        /// ER_applicant_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_applicant_key")]
        public string ER_applicant_key { get; set; }
        /// <summary>
        /// ER_applicant_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_applicant_code")]
        public string ER_applicant_code { get; set; }
        /// <summary>
        /// ER_applicant_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_applicant_name")]
        public string ER_applicant_name { get; set; }
        /// <summary>
        /// ER_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_user_key")]
        public string ER_user_key { get; set; }
        /// <summary>
        /// ER_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_user_code")]
        public string ER_user_code { get; set; }
        /// <summary>
        /// ER_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_user_name")]
        public string ER_user_name { get; set; }
        /// <summary>
        /// ER_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_time")]
        public DateTime? ER_time { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// productline_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_key")]
        public string productline_key { get; set; }
        /// <summary>
        /// productline_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_code")]
        public string productline_code { get; set; }
        /// <summary>
        /// productline_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_name")]
        public string productline_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// solving_measures
        /// </summary>
        /// <returns></returns>
        [DisplayName("solving_measures")]
        public string solving_measures { get; set; }
        /// <summary>
        /// fault_description
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_description")]
        public string fault_description { get; set; }
        /// <summary>
        /// ER_task_launch_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_task_launch_time")]
        public DateTime? ER_task_launch_time { get; set; }
        /// <summary>
        /// fault_response_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_response_time")]
        public DateTime? fault_response_time { get; set; }
        /// <summary>
        /// ER_state
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_state")]
        public string ER_state { get; set; }
        /// <summary>
        /// length_of_Repair
        /// </summary>
        /// <returns></returns>
        [DisplayName("length_of_Repair")]
        public string length_of_Repair { get; set; }
        /// <summary>
        /// length_of_fault
        /// </summary>
        /// <returns></returns>
        [DisplayName("length_of_fault")]
        public string length_of_fault { get; set; }
        /// <summary>
        /// ER_result
        /// </summary>
        /// <returns></returns>
        [DisplayName("ER_result")]
        public string ER_result { get; set; }
        /// <summary>
        /// er_dept_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_dept_key")]
        public string er_dept_key { get; set; }
        /// <summary>
        /// er_dept_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_dept_code")]
        public string er_dept_code { get; set; }
        /// <summary>
        /// er_dept_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_dept_name")]
        public string er_dept_name { get; set; }
        /// <summary>
        /// er_Cuser_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_Cuser_key")]
        public string er_Cuser_key { get; set; }
        /// <summary>
        /// er_Cuser_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_Cuser_code")]
        public string er_Cuser_code { get; set; }
        /// <summary>
        /// er_Cuser_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_Cuser_name")]
        public string er_Cuser_name { get; set; }
        /// <summary>
        /// er_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("er_level")]
        public string er_level { get; set; }
        /// <summary>
        /// equipment_shutdown_H
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_shutdown_H")]
        public int? equipment_shutdown_H { get; set; }
        /// <summary>
        /// equipment_shutdown_M
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_shutdown_M")]
        public int? equipment_shutdown_M { get; set; }
        /// <summary>
        /// fault_case
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_case")]
        public string fault_case { get; set; }
        /// <summary>
        /// fault_category
        /// </summary>
        /// <returns></returns>
        [DisplayName("fault_category")]
        public string fault_category { get; set; }
        /// <summary>
        /// parts_infor
        /// </summary>
        /// <returns></returns>
        [DisplayName("parts_infor")]
        public string parts_infor { get; set; }
        /// <summary>
        /// B_Tsure_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("B_Tsure_time")]
        public DateTime? B_Tsure_time { get; set; }
        /// <summary>
        /// A_Tsure_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("A_Tsure_time")]
        public DateTime? A_Tsure_time { get; set; }
        /// <summary>
        /// ERcomplete_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("ERcomplete_time")]
        public DateTime? ERcomplete_time { get; set; }
        /// <summary>
        /// UserSure_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("UserSure_time")]
        public DateTime? UserSure_time { get; set; }
        /// <summary>
        /// inputData_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("inputData_time")]
        public DateTime? inputData_time { get; set; }
        /// <summary>
        /// imagefile
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagefile")]
        public string imagefile { get; set; }
        /// <summary>
        /// imagepath
        /// </summary>
        /// <returns></returns>
        [DisplayName("imagepath")]
        public string imagepath { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.p_er_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.p_er_key = KeyValue;
                                            }
        #endregion
    }
}