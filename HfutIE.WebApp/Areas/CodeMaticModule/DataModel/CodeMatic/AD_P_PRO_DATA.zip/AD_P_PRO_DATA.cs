//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_PRO_DATA
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.07.17 08:59</date>
    /// </author>
    /// </summary>
    [Description("AD_P_PRO_DATA")]
    [PrimaryKey("pro_data_id")]
    public class AD_P_PRO_DATA : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// pro_data_id
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_data_id")]
        public string pro_data_id { get; set; }
        /// <summary>
        /// lot_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_key")]
        public string lot_key { get; set; }
        /// <summary>
        /// lot_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_code")]
        public string lot_code { get; set; }
        /// <summary>
        /// lot_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_type")]
        public string lot_type { get; set; }
        /// <summary>
        /// plan_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_num")]
        public Single? plan_num { get; set; }
        /// <summary>
        /// plan_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("plan_no")]
        public string plan_no { get; set; }
        /// <summary>
        /// product_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_key")]
        public string product_key { get; set; }
        /// <summary>
        /// product_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_born_code")]
        public string product_born_code { get; set; }
        /// <summary>
        /// plat_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("plat_name")]
        public string plat_name { get; set; }
        /// <summary>
        /// part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key")]
        public string part_key { get; set; }
        /// <summary>
        /// part_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_name")]
        public string part_name { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_batch_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_batch_no")]
        public string product_batch_no { get; set; }
        /// <summary>
        /// product_serial_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_serial_no")]
        public string product_serial_no { get; set; }
        /// <summary>
        /// site_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_key")]
        public string site_key { get; set; }
        /// <summary>
        /// site_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_code")]
        public string site_code { get; set; }
        /// <summary>
        /// site_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("site_name")]
        public string site_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// equip_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_code")]
        public string equip_code { get; set; }
        /// <summary>
        /// equip_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_name")]
        public string equip_name { get; set; }
        /// <summary>
        /// user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_key")]
        public string user_key { get; set; }
        /// <summary>
        /// user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_code")]
        public string user_code { get; set; }
        /// <summary>
        /// user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_name")]
        public string user_name { get; set; }
        /// <summary>
        /// team_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("team_key")]
        public string team_key { get; set; }
        /// <summary>
        /// team_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("team_code")]
        public string team_code { get; set; }
        /// <summary>
        /// team_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("team_name")]
        public string team_name { get; set; }
        /// <summary>
        /// collection_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("collection_time")]
        public DateTime? collection_time { get; set; }
        /// <summary>
        /// collection_date
        /// </summary>
        /// <returns></returns>
        [DisplayName("collection_date")]
        public DateTime? collection_date { get; set; }
        /// <summary>
        /// year
        /// </summary>
        /// <returns></returns>
        [DisplayName("year")]
        public int? year { get; set; }
        /// <summary>
        /// month
        /// </summary>
        /// <returns></returns>
        [DisplayName("month")]
        public int? month { get; set; }
        /// <summary>
        /// day
        /// </summary>
        /// <returns></returns>
        [DisplayName("day")]
        public int? day { get; set; }
        /// <summary>
        /// data_derive_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("data_derive_type")]
        public int? data_derive_type { get; set; }
        /// <summary>
        /// c_addr_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("c_addr_key")]
        public string c_addr_key { get; set; }
        /// <summary>
        /// c_addr_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("c_addr_name")]
        public string c_addr_name { get; set; }
        /// <summary>
        /// c_addr_path
        /// </summary>
        /// <returns></returns>
        [DisplayName("c_addr_path")]
        public string c_addr_path { get; set; }
        /// <summary>
        /// is_fied
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_fied")]
        public int? is_fied { get; set; }
        /// <summary>
        /// pro_ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_ID")]
        public string pro_ID { get; set; }
        /// <summary>
        /// pro_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_model_no")]
        public string pro_model_no { get; set; }
        /// <summary>
        /// pro_isSpecial
        /// </summary>
        /// <returns></returns>
        [DisplayName("pro_isSpecial")]
        public string pro_isSpecial { get; set; }
        /// <summary>
        /// platform_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("platform_no")]
        public string platform_no { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.pro_data_id = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.pro_data_id = KeyValue;
                                            }
        #endregion
    }
}