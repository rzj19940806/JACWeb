//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Spot_Check_item
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.13 10:19</date>
    /// </author>
    /// </summary>
    [Description("AD_Spot_Check_item")]
    [PrimaryKey("P_Qua_item_key")]
    public class AD_Spot_Check_item : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// P_Qua_item_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_Qua_item_key")]
        public string P_Qua_item_key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// task_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_code")]
        public string task_code { get; set; }
        /// <summary>
        /// lot_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("lot_name")]
        public string lot_name { get; set; }
        /// <summary>
        /// product_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_name")]
        public string product_name { get; set; }
        /// <summary>
        /// product_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_code")]
        public string product_code { get; set; }
        /// <summary>
        /// product_type
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_type")]
        public string product_type { get; set; }
        /// <summary>
        /// product_model_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_model_no")]
        public string product_model_no { get; set; }
        /// <summary>
        /// product_struct_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_struct_no")]
        public string product_struct_no { get; set; }
        /// <summary>
        /// product_abb
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_abb")]
        public string product_abb { get; set; }
        /// <summary>
        /// product_draw_no
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_draw_no")]
        public string product_draw_no { get; set; }
        /// <summary>
        /// product_born_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("product_born_code")]
        public string product_born_code { get; set; }
        /// <summary>
        /// part_number
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_number")]
        public string part_number { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// p_line_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_key")]
        public string p_line_key { get; set; }
        /// <summary>
        /// p_line_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_code")]
        public string p_line_code { get; set; }
        /// <summary>
        /// p_line_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("p_line_name")]
        public string p_line_name { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_key")]
        public string user_key { get; set; }
        /// <summary>
        /// user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_code")]
        public string user_code { get; set; }
        /// <summary>
        /// user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("user_name")]
        public string user_name { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// equip_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_code")]
        public string equip_code { get; set; }
        /// <summary>
        /// equip_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_name")]
        public string equip_name { get; set; }
        /// <summary>
        /// Qua_item_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_key")]
        public string Qua_item_key { get; set; }
        /// <summary>
        /// Qua_item_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_code")]
        public string Qua_item_code { get; set; }
        /// <summary>
        /// Qua_item_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_name")]
        public string Qua_item_name { get; set; }
        /// <summary>
        /// Qua_item_rec_cate
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_rec_cate")]
        public string Qua_item_rec_cate { get; set; }
        /// <summary>
        /// Qua_item_stan
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_stan")]
        public string Qua_item_stan { get; set; }
        /// <summary>
        /// Qua_Item_upl
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_Item_upl")]
        public Single? Qua_Item_upl { get; set; }
        /// <summary>
        /// Qua_Item_downl
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_Item_downl")]
        public Single? Qua_Item_downl { get; set; }
        /// <summary>
        /// Qua_item_targ
        /// </summary>
        /// <returns></returns>
        [DisplayName("Qua_item_targ")]
        public string Qua_item_targ { get; set; }
        /// <summary>
        /// actual_value
        /// </summary>
        /// <returns></returns>
        [DisplayName("actual_value")]
        public Single? actual_value { get; set; }
        /// <summary>
        /// result
        /// </summary>
        /// <returns></returns>
        [DisplayName("result")]
        public string result { get; set; }
        /// <summary>
        /// frequency
        /// </summary>
        /// <returns></returns>
        [DisplayName("frequency")]
        public string frequency { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.P_Qua_item_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.P_Qua_item_key = KeyValue;
                                            }
        #endregion
    }
}