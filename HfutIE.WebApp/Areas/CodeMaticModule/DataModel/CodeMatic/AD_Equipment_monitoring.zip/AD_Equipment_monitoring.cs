//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_Equipment_monitoring
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.11.01 14:57</date>
    /// </author>
    /// </summary>
    [Description("AD_Equipment_monitoring")]
    [PrimaryKey("EM_P_key")]
    public class AD_Equipment_monitoring : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// EM_P_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_P_key")]
        public string EM_P_key { get; set; }
        /// <summary>
        /// equipment_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_key")]
        public string equipment_key { get; set; }
        /// <summary>
        /// Maintenance_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("Maintenance_level")]
        public string Maintenance_level { get; set; }
        /// <summary>
        /// Maintenance_cycle
        /// </summary>
        /// <returns></returns>
        [DisplayName("Maintenance_cycle")]
        public string Maintenance_cycle { get; set; }
        /// <summary>
        /// Equipment_running_length
        /// </summary>
        /// <returns></returns>
        [DisplayName("Equipment_running_length")]
        public string Equipment_running_length { get; set; }
        /// <summary>
        /// last_EM_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_EM_time")]
        public DateTime? last_EM_time { get; set; }
        /// <summary>
        /// state
        /// </summary>
        /// <returns></returns>
        [DisplayName("state")]
        public string state { get; set; }
        /// <summary>
        /// EM_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_key")]
        public string EM_user_key { get; set; }
        /// <summary>
        /// EM_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_code")]
        public string EM_user_code { get; set; }
        /// <summary>
        /// EM_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_name")]
        public string EM_user_name { get; set; }
        /// <summary>
        /// Check_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_key")]
        public string Check_user_key { get; set; }
        /// <summary>
        /// Check_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_code")]
        public string Check_user_code { get; set; }
        /// <summary>
        /// Check_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_name")]
        public string Check_user_name { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creator_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_code")]
        public string creator_code { get; set; }
        /// <summary>
        /// creator_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_name")]
        public string creator_name { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// modifier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_code")]
        public string modifier_code { get; set; }
        /// <summary>
        /// modifier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_name")]
        public string modifier_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.EM_P_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.EM_P_key = KeyValue;
                                            }
        #endregion
    }
}