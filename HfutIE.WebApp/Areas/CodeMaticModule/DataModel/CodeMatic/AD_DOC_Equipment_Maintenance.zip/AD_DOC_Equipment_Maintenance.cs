//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_DOC_Equipment_Maintenance
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.12.11 09:49</date>
    /// </author>
    /// </summary>
    [Description("AD_DOC_Equipment_Maintenance")]
    [PrimaryKey("EM_P_key")]
    public class AD_DOC_Equipment_Maintenance : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// EM_P_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_P_key")]
        public string EM_P_key { get; set; }
        /// <summary>
        /// task_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("task_key")]
        public string task_key { get; set; }
        /// <summary>
        /// equipment_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_key")]
        public string equipment_key { get; set; }
        /// <summary>
        /// equipment_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_code")]
        public string equipment_code { get; set; }
        /// <summary>
        /// equipment_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("equipment_name")]
        public string equipment_name { get; set; }
        /// <summary>
        /// EM_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_key")]
        public string EM_user_key { get; set; }
        /// <summary>
        /// EM_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_code")]
        public string EM_user_code { get; set; }
        /// <summary>
        /// EM_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_user_name")]
        public string EM_user_name { get; set; }
        /// <summary>
        /// Check_user_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_key")]
        public string Check_user_key { get; set; }
        /// <summary>
        /// Check_user_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_code")]
        public string Check_user_code { get; set; }
        /// <summary>
        /// Check_user_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("Check_user_name")]
        public string Check_user_name { get; set; }
        /// <summary>
        /// EM_start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_start_time")]
        public DateTime? EM_start_time { get; set; }
        /// <summary>
        /// EM_end_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("EM_end_time")]
        public DateTime? EM_end_time { get; set; }
        /// <summary>
        /// check_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_time")]
        public DateTime? check_time { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// wc_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_code")]
        public string wc_code { get; set; }
        /// <summary>
        /// wc_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_name")]
        public string wc_name { get; set; }
        /// <summary>
        /// productline_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_key")]
        public string productline_key { get; set; }
        /// <summary>
        /// productline_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_code")]
        public string productline_code { get; set; }
        /// <summary>
        /// productline_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("productline_name")]
        public string productline_name { get; set; }
        /// <summary>
        /// area_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_key")]
        public string area_key { get; set; }
        /// <summary>
        /// area_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_code")]
        public string area_code { get; set; }
        /// <summary>
        /// area_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("area_name")]
        public string area_name { get; set; }
        /// <summary>
        /// Maintenance_level
        /// </summary>
        /// <returns></returns>
        [DisplayName("Maintenance_level")]
        public string Maintenance_level { get; set; }
        /// <summary>
        /// Maintenance_cycle
        /// </summary>
        /// <returns></returns>
        [DisplayName("Maintenance_cycle")]
        public string Maintenance_cycle { get; set; }
        /// <summary>
        /// Equipment_running_length
        /// </summary>
        /// <returns></returns>
        [DisplayName("Equipment_running_length")]
        public string Equipment_running_length { get; set; }
        /// <summary>
        /// last_EM_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("last_EM_time")]
        public DateTime? last_EM_time { get; set; }
        /// <summary>
        /// P_EM_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("P_EM_time")]
        public DateTime? P_EM_time { get; set; }
        /// <summary>
        /// state
        /// </summary>
        /// <returns></returns>
        [DisplayName("state")]
        public string state { get; set; }
        /// <summary>
        /// check_result
        /// </summary>
        /// <returns></returns>
        [DisplayName("check_result")]
        public string check_result { get; set; }
        /// <summary>
        /// create_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("create_time")]
        public DateTime? create_time { get; set; }
        /// <summary>
        /// creator_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_key")]
        public string creator_key { get; set; }
        /// <summary>
        /// creator_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_code")]
        public string creator_code { get; set; }
        /// <summary>
        /// creator_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("creator_name")]
        public string creator_name { get; set; }
        /// <summary>
        /// modify_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("modify_time")]
        public DateTime? modify_time { get; set; }
        /// <summary>
        /// modifier_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_key")]
        public string modifier_key { get; set; }
        /// <summary>
        /// modifier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_code")]
        public string modifier_code { get; set; }
        /// <summary>
        /// modifier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("modifier_name")]
        public string modifier_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.EM_P_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.EM_P_key = KeyValue;
                                            }
        #endregion
    }
}