//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_ACCESS_INFO
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.08.18 09:27</date>
    /// </author>
    /// </summary>
    [Description("AD_ACCESS_INFO")]
    [PrimaryKey("access_key")]
    public class AD_ACCESS_INFO : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// access_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_key")]
        public string access_key { get; set; }
        /// <summary>
        /// interchanger_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("interchanger_key")]
        public string interchanger_key { get; set; }
        /// <summary>
        /// access_order
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_order")]
        public string access_order { get; set; }
        /// <summary>
        /// access_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_code")]
        public string access_code { get; set; }
        /// <summary>
        /// access_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_name")]
        public string access_name { get; set; }
        /// <summary>
        /// access_ip_addr
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_ip_addr")]
        public string access_ip_addr { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// equip_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("equip_key")]
        public string equip_key { get; set; }
        /// <summary>
        /// is_arrange_reticle
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_arrange_reticle")]
        public int? is_arrange_reticle { get; set; }
        /// <summary>
        /// is_arrange_elewire
        /// </summary>
        /// <returns></returns>
        [DisplayName("is_arrange_elewire")]
        public int? is_arrange_elewire { get; set; }
        /// <summary>
        /// elewire_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("elewire_name")]
        public string elewire_name { get; set; }
        /// <summary>
        /// offer_ele_position
        /// </summary>
        /// <returns></returns>
        [DisplayName("offer_ele_position")]
        public string offer_ele_position { get; set; }
        /// <summary>
        /// access_usetime
        /// </summary>
        /// <returns></returns>
        [DisplayName("access_usetime")]
        public DateTime? access_usetime { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.access_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.access_key = KeyValue;
                                            }
        #endregion
    }
}