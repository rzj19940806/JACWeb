//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// AD_P_Tool
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.14 10:58</date>
    /// </author>
    /// </summary>
    [Description("AD_P_Tool")]
    [PrimaryKey("t_key")]
    public class AD_P_Tool : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// t_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("t_key")]
        public string t_key { get; set; }
        /// <summary>
        /// plat_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("plat_key")]
        public string plat_key { get; set; }
        /// <summary>
        /// part_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("part_key")]
        public string part_key { get; set; }
        /// <summary>
        /// wc_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("wc_key")]
        public string wc_key { get; set; }
        /// <summary>
        /// tool_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("tool_name")]
        public string tool_name { get; set; }
        /// <summary>
        /// tool_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("tool_code")]
        public string tool_code { get; set; }
        /// <summary>
        /// DLife
        /// </summary>
        /// <returns></returns>
        [DisplayName("DLife")]
        public Single? DLife { get; set; }
        /// <summary>
        /// alarm
        /// </summary>
        /// <returns></returns>
        [DisplayName("alarm")]
        public Single? alarm { get; set; }
        /// <summary>
        /// supplier_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_code")]
        public string supplier_code { get; set; }
        /// <summary>
        /// supplier_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("supplier_name")]
        public string supplier_name { get; set; }
        /// <summary>
        /// sum_process_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("sum_process_num")]
        public Single? sum_process_num { get; set; }
        /// <summary>
        /// status
        /// </summary>
        /// <returns></returns>
        [DisplayName("status")]
        public Single? status { get; set; }
        /// <summary>
        /// ud_num
        /// </summary>
        /// <returns></returns>
        [DisplayName("ud_num")]
        public Single? ud_num { get; set; }
        /// <summary>
        /// start_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("start_time")]
        public DateTime? start_time { get; set; }
        /// <summary>
        /// scrap_time
        /// </summary>
        /// <returns></returns>
        [DisplayName("scrap_time")]
        public DateTime? scrap_time { get; set; }
        /// <summary>
        /// install_man_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("install_man_key")]
        public string install_man_key { get; set; }
        /// <summary>
        /// install_man_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("install_man_code")]
        public string install_man_code { get; set; }
        /// <summary>
        /// install_man_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("install_man_name")]
        public string install_man_name { get; set; }
        /// <summary>
        /// scrap_man_key
        /// </summary>
        /// <returns></returns>
        [DisplayName("scrap_man_key")]
        public string scrap_man_key { get; set; }
        /// <summary>
        /// scrap_man_code
        /// </summary>
        /// <returns></returns>
        [DisplayName("scrap_man_code")]
        public string scrap_man_code { get; set; }
        /// <summary>
        /// scrap_man_name
        /// </summary>
        /// <returns></returns>
        [DisplayName("scrap_man_name")]
        public string scrap_man_name { get; set; }
        /// <summary>
        /// remarks
        /// </summary>
        /// <returns></returns>
        [DisplayName("remarks")]
        public string remarks { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.t_key = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.t_key = KeyValue;
                                            }
        #endregion
    }
}