//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2018
// Software Developers @ HfutIE 2018
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// AD_P_Tool
    /// <author>
    ///		<name>she</name>
    ///		<date>2018.04.14 10:58</date>
    /// </author>
    /// </summary>
    public class AD_P_ToolBll : RepositoryFactory<AD_P_Tool>
    {
    }
}