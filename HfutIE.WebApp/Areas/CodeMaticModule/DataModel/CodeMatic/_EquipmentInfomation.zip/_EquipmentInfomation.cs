//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2021
// Software Developers @ HfutIE 2021
//=====================================================================================

using HfutIE.DataAccess.Attributes;
using HfutIE.Utilities;
using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace HfutIE.Entity
{
    /// <summary>
    /// �豸������Ϣ
    /// <author>
    ///		<name>she</name>
    ///		<date>2021.02.19 09:17</date>
    /// </author>
    /// </summary>
    [Description("�豸������Ϣ")]
    [PrimaryKey("ID")]
    public class _EquipmentInfomation : BaseEntity
    {
        #region ��ȡ/���� �ֶ�ֵ
        /// <summary>
        /// ����
        /// </summary>
        /// <returns></returns>
        [DisplayName("����")]
        public string ID { get; set; }
        /// <summary>
        /// �豸���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸���")]
        public string EquipmentCode { get; set; }
        /// <summary>
        /// �����豸����ID
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����豸����ID")]
        public string EquipmentGroupID { get; set; }
        /// <summary>
        /// �豸�������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸�������")]
        public string EquipmentGroupCode { get; set; }
        /// <summary>
        /// �豸����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸����")]
        public string EquipmentName { get; set; }
        /// <summary>
        /// �豸���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸���")]
        public string EquipmentCategory { get; set; }
        /// <summary>
        /// �豸����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸����")]
        public string EquipmentType { get; set; }
        /// <summary>
        /// �豸�ͺ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸�ͺ�")]
        public string EquipmentModel { get; set; }
        /// <summary>
        /// �豸ͼƬ
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸ͼƬ")]
        public string EquipmentImage { get; set; }
        /// <summary>
        /// �豸����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸����")]
        public string EquipmentMaker { get; set; }
        /// <summary>
        /// �豸����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸����")]
        public string EquipmentLife { get; set; }
        /// <summary>
        /// �豸��������
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸��������")]
        public DateTime? EquipmentMakeTime { get; set; }
        /// <summary>
        /// �豸���תʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸���תʱ��")]
        public decimal? MaxIdleTime { get; set; }
        /// <summary>
        /// �Ƿ���
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƿ���")]
        public bool? IsMonitor { get; set; }
        /// <summary>
        /// ʱ�䵥λ
        /// </summary>
        /// <returns></returns>
        [DisplayName("ʱ�䵥λ")]
        public string TimeUnit { get; set; }
        /// <summary>
        /// �豸����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�豸����")]
        public string EquipmentDescription { get; set; }
        /// <summary>
        /// ά������(��)
        /// </summary>
        /// <returns></returns>
        [DisplayName("ά������(��)")]
        public int? MaintenanceCycle { get; set; }
        /// <summary>
        /// ��ǰ�ڣ��죩
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ǰ�ڣ��죩")]
        public int? LeadTime { get; set; }
        /// <summary>
        /// �Ƿ�����
        /// </summary>
        /// <returns></returns>
        [DisplayName("�Ƿ�����")]
        public bool? IsEnable { get; set; }
        /// <summary>
        /// ��Ч��
        /// </summary>
        /// <returns></returns>
        [DisplayName("��Ч��")]
        public bool? IsAvailable { get; set; }
        /// <summary>
        /// ����ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("����ʱ��")]
        public DateTime? CreateTime { get; set; }
        /// <summary>
        /// �����ˣ�ForeignKey��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�����ˣ�ForeignKey��")]
        public string CreatorID { get; set; }
        /// <summary>
        /// �ϴ��޸�ʱ��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�ϴ��޸�ʱ��")]
        public DateTime? LastModifiedTime { get; set; }
        /// <summary>
        /// �޸��ˣ�ForeignKey��
        /// </summary>
        /// <returns></returns>
        [DisplayName("�޸��ˣ�ForeignKey��")]
        public string ModifierID { get; set; }
        /// <summary>
        /// ��ע
        /// </summary>
        /// <returns></returns>
        [DisplayName("��ע")]
        public string Remarks { get; set; }
        /// <summary>
        /// Ԥ���ֶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ���ֶ�")]
        public string Reserve1 { get; set; }
        /// <summary>
        /// Ԥ���ֶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ���ֶ�")]
        public string Reserve2 { get; set; }
        /// <summary>
        /// Ԥ���ֶ�
        /// </summary>
        /// <returns></returns>
        [DisplayName("Ԥ���ֶ�")]
        public string Reserve3 { get; set; }
        #endregion

        #region ��չ����
        /// <summary>
        /// ��������
        /// </summary>
        public override void Create()
        {
            this.ID = CommonHelper.GetGuid;
                                            }
        /// <summary>
        /// �༭����
        /// </summary>
        /// <param name="KeyValue"></param>
        public override void Modify(string KeyValue)
        {
            this.ID = KeyValue;
                                            }
        #endregion
    }
}