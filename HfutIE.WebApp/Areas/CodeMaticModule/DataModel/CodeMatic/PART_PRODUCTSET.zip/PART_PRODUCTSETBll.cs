//=====================================================================================
// All Rights Reserved , Copyright @ HfutIE 2017
// Software Developers @ HfutIE 2017
//=====================================================================================

using HfutIE.Entity;
using HfutIE.Repository;
using HfutIE.Utilities;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace HfutIE.Business
{
    /// <summary>
    /// PART_PRODUCTSET
    /// <author>
    ///		<name>she</name>
    ///		<date>2017.03.06 15:07</date>
    /// </author>
    /// </summary>
    public class PART_PRODUCTSETBll : RepositoryFactory<PART_PRODUCTSET>
    {
    }
}